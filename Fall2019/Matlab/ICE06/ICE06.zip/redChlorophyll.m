% Riley Payung
% 10/2/2019
% ICE06 Part A and B

% Initialization of the F Matrix.
% Format: [F Q a b;
%         F Q a b;
%         ...;
%         F Q a b]

% VARIABLE DECLARATION SECTION
FMat = [0 10 2 2;
        0 10 2.5 2.5;
        0 10 5 3;
        0 25 2.5 2;
        0 25 5 3.5;
        0 28 7 4.5]

% COMPUTATION SECTION
function F = redChlorophy(Q,a,b)
  F = (Q / a)^(1/b); % Created a reusable function for the function given.
end
for i = 1:size(FMat,1) % for each level of the matrix, calculate F.
  FMat(i,1) = redChlorophy(FMat(i,2),FMat(i,3),FMat(i,4))
end

h = plot(FMat)
% OPTIONAL: Displayed output from a variable
%FMat =
%
%   2.2361   10.0000    2.0000    2.0000
%   1.7411   10.0000    2.5000    2.5000
%   1.2599   10.0000    5.0000    3.0000
%   3.1623   25.0000    2.5000    2.0000
%   1.5838   25.0000    5.0000    3.5000
%   1.3608   28.0000    7.0000    4.5000