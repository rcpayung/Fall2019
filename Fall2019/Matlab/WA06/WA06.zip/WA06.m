% Riley Payung
% 10/7/2019
% Question WA06 Part A

% Variable Declaration Section
K1 = [100 150 100];
K2 = [125 75 200];
R = [0.01 0.1 0.025];


% Computation Section

B = [bVal(K1(1),K2(1),R(1)),bVal(K1(2),K2(2),R(2)),bVal(K1(3),K2(3),R(3))];
C = [cVal(K1(1),K2(1),R(1)),cVal(K1(2),K2(2),R(2)),cVal(K1(3),K2(3),R(3))];

% Output Section

tab = table(B,C,K1,K2,R);
disp(tab);

% Functions
function c = cVal(k1,k2,r)
    a0 = 200;
    c = (k2 / (k1 + k2)) * a0 * exp(r);
end

function b = bVal(k1,k2,r)
    b = (k2 / (k1 + k2)) * cVal(k1,k2,r) * exp(r);
end
