% Riley Payung
% 10/7/2019
% Question WA06 Part C

% Variable Declaration Section
h = 6.626;
c = 2.998;
J2eV = 1.602;
Lambda = 400:10:500;

% Computation Section

E = 1:3;

for i = 1:size(Lambda,1)
   E(i) = ((h*c) / Lambda(i)) / J2eV;
end

% Output Section
disp('Energy in eV');
disp(E);
% Functions

