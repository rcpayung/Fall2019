function F = rpayung(Q,a,b)
  F = (Q / a)^(1/b);
end