% Riley Payung
% 10/14/2019
% WA07 Part C

%clear workspace
clear;clc;

%variable declaration section
A = [1 2;
    3 4];
B = [5 6;
    7 8];

%computation section
A = A.^2;
B = B.^0.5;

disp(A);
disp(B);