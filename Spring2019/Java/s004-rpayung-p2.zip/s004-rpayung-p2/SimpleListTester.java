import static org.junit.Assert.*;

import java.util.NoSuchElementException;

import org.junit.Before;
import org.junit.Test;

public class SimpleListTester {

	SimpleList<Integer> list;
	
	@Before
	public void setUp() throws Exception {
		list = new SimpleList<>();
	}

	@Test
	public void testAdd() {
		list.add(0, 10);
		list.add(0, 20);
		
		assertEquals((Integer) 20, list.get(0));
	}
	
	@Test
	public void testAppend() {
		list.add(40);
		
		assertEquals((Integer) 40, list.get(list.size() - 1));
	}

	@Test
	public void testRemove() {
		list.add(10);
		assertEquals((Integer) 10, list.remove(0));
		
	}
}
