import java.util.Queue;
import java.util.NoSuchElementException;

/**
 * Creates a new SimpleQueue object. implements the Queue interface.
 * 
 * @author Riley Payung
 * CS 310
 * */

//Class for a simple queue based on SimpleList
//The "front" of the queue should be the front of
//the list.

//READ THE DOCUMENTATION for the Queue interface for more information
//on how these methods should work and when exceptions should
//be thrown. This data structure does not allow adding null.

//DO NOT re-implement nodes in this class... remember how
//inheritance works in Java and make use of that!
class SimpleQueue<T> extends SimpleList<T> implements Queue<T> {

	/**
	 * Adds the specified value to the back of the Queue.
	 * 
	 * O(1)
	 * 
	 * @param item value to be added.
	 * @throws NullPointerException if the value is invalid.
	 * @return returns true if the value has been added.
	 */
	public boolean add(T item) {
		// O(1)
		if (item == null)
			throw new NullPointerException();
		return super.add(item);
	}

	/**
	 * Offers the item to the back of the list.
	 * 
	 * O(1)
	 * 
	 * @param item value to be added.
	 * @throws NullPointerException if the value is invalid.
	 * @return returns true if the value has been added.
	 */
	public boolean offer(T item) {
		// O(1)
		if (item == null) {
			throw new NullPointerException();
		}
		return super.add(item);
	}
	/**
	 * removes the item from the front of the list.
	 * 
	 * O(1)
	 * 
	 * @throws NoSuchElementException if the list is empty.
	 * @return returns the value removed.
	 */
	public T remove() {
		// O(1)
		if (this.isEmpty())
			throw new NoSuchElementException();
		return super.remove(0);
	}

	/**
	 * returns the item from the front of the list.
	 * 
	 * O(1)
	 * 
	 * @return returns the value removed. null if the list is empty.
	 */
	public T poll() {
		// O(1)
		if (this.isEmpty())
			return null;
		return super.remove(0);
	}
	/**
	 * gets the item at the front of the list.
	 * 
	 * O(1)
	 * 
	 * @throws NoSuchElementException if the list is empty.
	 * @return returns the value at the front of the list.
	 */
	public T element() {
		// O(1)
		if (this.isEmpty())
			throw new NoSuchElementException();
		return this.get(0);
	}
	/**
	 * gets the item at the front of the list.
	 * 
	 * O(1)
	 * 
	 * @return returns the value at the front of the list. null if the list is empty.
	 */
	public T peek() {
		// O(1)
		if (this.isEmpty())
			return null;
		return this.get(0);
	}

	// -------------------------------------------------------------
	// Main Method For Your Testing -- Edit all you want
	// -------------------------------------------------------------

	public static void main(String[] args) {
		SimpleQueue<Integer> nums = new SimpleQueue<>();

		nums.offer(2);
		nums.offer(3);
		nums.offer(5);

		for (Integer i : nums) {
			System.out.println(i);
		}

		if (nums.peek() == 2 && nums.size() == 3) {
			System.out.println("Yay 1");
		}

		if (nums.poll() == 2 && nums.poll() == 3 && nums.poll() == 5 && nums.poll() == null) {
			System.out.println("Yay 2");
		}

		nums.add(0, 10);
		if (nums.peek() == 10) {
			System.out.println("Yay 3");
		}
		nums.add(1, 20);
		if (nums.get(1) == 20) {
			System.out.println("Yay 4");
		}
		nums.add(2, 30);
		if (nums.get(2) == 30) {
			System.out.println("Yay 5");
		}
	}
}