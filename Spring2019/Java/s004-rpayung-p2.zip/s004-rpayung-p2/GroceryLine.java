import java.util.Queue;

/**
 * Grocery Line object implements the SimpleQueue of people. implements comparable to compare to another line.
 * 
 * @author Riley Payung
 * 
 * CS310
 * */
public class GroceryLine extends SimpleQueue<Person> implements Comparable<GroceryLine> {
	/**
	 * the id of the line.
	 * */
	private int id = 0;
	/**
	 * number of items
	 * */
	private int items = 0;

	/**
	 * Creates a new Grocery Line with specified id
	 * @param id the id of the line
	 * */
	public GroceryLine(int id) {
		this.id = id;
	}

	/**
	 * Gets the id of this grocery line
	 * 
	 * O(1)
	 * 
	 * @return returns the id of this line.
	 * */
	public int getId() {
		return this.id;
	}

	/**
	 * returns the total number of elements in the line.
	 * 
	 * O(N)
	 * 
	 * @return number of items.
	 * */
	public int itemsInLine() {
		items = 0;
		for (int i = 0; i < size(); i++) {
			this.items += this.get(i).getNumItems();
		}
		return items;
	}

	/**
	 * Compares this grocery line to another grocery line.
	 * 
	 * O(n+m)
	 * 
	 * @param otherLine Grocery line to compare this one to.
	 * @return 0 if the lines are the same. -1 if the second line is bigger and 1 if this line is bigger.
	 * */
	public int compareTo(GroceryLine otherLine) {
		int size = 0, sizeOther = 0;
		for (int i = 0; i < this.size(); i++)
			size += this.get(i).getNumItems();
		for (int i = 0; i < otherLine.size(); i++)
			sizeOther += otherLine.get(i).getNumItems();
		if (size == sizeOther)
			return 0;
		else
			return (size > sizeOther) ? 1 : -1;
	}

	/**
	 * Processes 1 item from the first person.
	 * 
	 * O(1)
	 * 
	 */
	public void processItem() {
		this.get(0).removeItem();
	}

	@Override
	public String toString() {
		StringBuilder build = new StringBuilder();

		build.append("Line " + id + ": ");
		for (int i = 0; i < this.size(); i++) {
			build.append(this.get(i));
		}

		return build.toString();
	}

	// -------------------------------------------------------------
	// Main Method For Your Testing -- Edit all you want
	// -------------------------------------------------------------

	public static void main(String[] args) {
		GroceryLine line = new GroceryLine(0);
		Person mason = new Person(10);
		Person george = new Person(20);

		line.offer(mason);
		line.offer(george);

		if (line.getId() == 0 && line.itemsInLine() == 30) {
			System.out.println("Yay 1");
		}

		line.processItem();
		if (line.itemsInLine() == 29 && line.peek().getNumItems() == 9) {
			System.out.println("Yay 2");
		}

		GroceryLine line2 = new GroceryLine(1);
		Person washington = new Person(40);
		line2.offer(washington);

		if (line.compareTo(line2) < 0) {
			System.out.println("Yay 3");
		}
	}
}