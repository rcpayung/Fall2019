/**
 * Person Object
 * 
 * @author Riley Payung
 * CS 310
 * 
 * */
public class Person {
	/**items this person has */
	private int items = 0;
	
	/**
	 * Creates a new person object.
	 * 
	 * O(1)
	 * 
	 * @throws IllegalArgumentException if the number of items is less than 1.
	 * 
	 * @param numItems items this person has.
	 * */
	public Person(int numItems) {
		if (numItems < 1) {
			throw new IllegalArgumentException();
		}
		this.items = numItems;
	}
	
	/**
	 * Gets the number of items
	 * 
	 * O(1)
	 * 
	 * @return the number of items
	 * */
	public int getNumItems() {
		return this.items;
	}

	/**
	 * Removes an item from this person, checks to see if the person is finished "checking out"
	 * */
	public void removeItem() {
		if (!done()) {
			items--;
		}
	}
	
	/**
	 * Checks to see if this person is done "checking out" 
	 * @return true if the person doesnt have any items. false if not.
	 * */
	public boolean done() {
		if (items == 0) {
			return true;
		}
		return false;
	}

	public static void main(String[] args) {
		Person mason = new Person(2);
		if (mason.getNumItems() == 2 && !mason.done()) {
			System.out.println("Yay 1");
		}

		mason.removeItem();
		boolean ok = (mason.getNumItems() == 1);
		mason.removeItem();
		if (ok && mason.done()) {
			System.out.println("Yay 2");
		}
	}

	// -------------------------------------------------------------
	// DO NOT EDIT ANYTHING BELOW THIS LINE EXCEPT TO ADD JAVADOCS
	// -------------------------------------------------------------

	// provided toString() method
	public String toString() {
		return "Person(" + getNumItems() + ")";
	}
}