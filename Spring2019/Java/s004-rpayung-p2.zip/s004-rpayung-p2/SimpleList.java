import java.util.AbstractList;
import java.util.NoSuchElementException;
import java.util.Iterator;

/**
 * Creates a new SimpleList object. extends the AbstractList abstract class.
 * 
 * @author Riley Payung
 * CS 310
 * */


//Simple linked list class based on AbstractList
//READ THE DOCUMENTATION for AbstractList for more information
//on how these methods should work and when exceptions should
//be thrown. This data structure does not allow adding null
//elements.
public class SimpleList<T> extends AbstractList<T>{
	// Add more instance variables here...
	// private or protected only!
	/** the size of the list */
	private int size;
	/** the current object in the list */
	private DoubleNode<T> current;
	/** the last object in the list */
	private DoubleNode<T> tail;

	/**
	 * Creates a new SimpleList object. initializes all private variables as well as the head.
	 * */
	// Constructor
	public SimpleList() {
		// O(1)
		head = new DoubleNode<T>();
		tail = head;
		current = head;
		size = 0;
	}

	/**
	 * Size of the list
	 * 
	 * O(1)
	 * 
	 * @return the size of the list.
	 * */
	public int size() {
		return this.size;
	}

	/**
	 * Gets the object at the specified object.
	 * 
	 * O(N)
	 * 
	 * @param index - index to get.
	 * 
	 * @throws IndexOutOfBoundsException if the specified index is invalid.
	 * 
	 * @return object at index. null if not found.
	 * */
	public T get(int index) {
		checkIndex(index);
		int count = 0;
		for (T i : this) {
			if (count == index)
				return i;
			count++;
		}
		return null;
	}

	/**
	 * Sets the object at the specified index as the specified value.
	 * 
	 * O(N)
	 * 
	 * @param index - index to set at
	 * @param value - value to set at the given index.
	 * 
	 * @throws IndexOutOfBoundsException if the index specified is invalid.
	 * @throws NullPointerException if the value specified is invalid.
	 * 
	 * @return returns the old value if found, null if not.
	 * */
	public T set(int index, T value) {
		current = head;
		checkIndex(index);
		checkValue(value);
		for (int i = 0; i < size(); i++) {
			if (i == index) {
				T old = current.value;
				current.value = value;
				return old;
			}
			current = current.next;
		}
		return null;
	}

	/**
	 * Adds the specified value at the specified value.
	 * 
	 * O(N)
	 * 
	 * @param index - index to add at.
	 * @param value - value to add at the given index.
	 * 
	 * @throws IndexOutOfBoundsException if the index is invalid.
	 * @throws NullPointerException if the value is invalid.
	 * 
	 * */
	public void add(int index, T value) {
		current = head;
		checkIndex(index);
		checkValue(value);
		DoubleNode<T> node = new DoubleNode<T>(value);
		if (size() == 0 || index == size()) {
			add(value);
			return;
		} else if (index == 0) {
			node.next = head;
			head.prev = node;
			head = node;
			size++;
			return;
		} else {
			for (int i = 1; i < size() - 1; i++) {
				if (i == index) {
					node.next = current.next;
					node.prev = current;
					current.next.prev = node;
					current.next = node;
					size++;
					break;
				}
				current = current.next;
			}
		}
	}

	/**
	 * Appends the specified value at the end of the list.
	 * 
	 * O(1)
	 * 
	 * @param value - value to add.
	 * 
	 * @throws NullPointerException if value is invalid.
	 * 
	 * @return true if the value was added to this list.
	 * 
	 * */
	public boolean add(T value) {
		// O(1)
		checkValue(value);
		if (head.value == null || size == 0) {
			this.head.value = value;
			tail = head;
			size++;
			
			System.out.println(head.value);
			return true;
		} else {
			tail.next = new DoubleNode<T>(value);
			tail.next.prev = tail;
			tail = tail.next;
			size++;
			
			System.out.println(tail.value);
			return true;
		}
	}

	// removes the value at a given index and returns
	// the value removed
	/**
	 * Removes the value at the specified index.
	 * 
	 * O(N)
	 * 
	 * @param index - index to remove at.
	 * 
	 * @throws IndexOutOfBoundsException if the index is invalid.
	 * 
	 * @return the value removed. null if the value was not found.
	 * */
	public T remove(int index) {
		// O(n)
		checkIndex(index);
		if (this.isEmpty())
			return null;
		current = head;
		T old = null;
		if (index == 0) {
			if (this.size() == 1) {
				head.next = null;
				head.prev = null;
				size--;
				return head.value;
			}
			//first item
			old = head.value;
			head.next.prev = null;
			head = head.next;
			size--;
			return old;
		}
		if (index == size()) {
			//last item
			old = tail.value;
			tail = tail.prev;
			tail.next = null;
			size--;
			return old;
		}
		for (int i = 0; i < size(); i++) {
			if (i == index) {
				old = current.value;
				current.prev.next = current.next;
				current.next.prev = current.prev;
				size--;
				break;
			}
			current = current.next;
		}
		
		return old;
	}
	
	/**
	 * Checks the index of the specified index for validity.
	 * 
	 * @param index the index to check.
	 * 
	 * @throws IndexOutOfBoundsException if the index is not valid.
	 * */
	private void checkIndex(int index) {
		if (index < 0 || index > size()) {
			throw new IndexOutOfBoundsException();
		}
	}

	/**
	 * Checks the value specified for validity.
	 * 
	 * @param value value to check.
	 * 
	 * @throws NullPointerException if the value is not valid.
	 * */
	private void checkValue(T value) {
		if (value == null) {
			throw new NullPointerException();
		}
	}
	// -------------------------------------------------------------
	// Main Method For Your Testing -- Edit all you want
	// -------------------------------------------------------------

	public static void main(String[] args) {
		SimpleList<Character> letters = new SimpleList<>();
		for (int i = 0; i < 5; i++)
			letters.add((char) (97 + i * 2));

		if (letters.size() == 5 && letters.get(0) == 'a') {
			System.out.println("Yay 1");
		}

		if (letters.set(1, 'b') == 'c' && letters.get(1) == 'b') {
			System.out.println("Yay 2");
		}

		letters.add(2, 'c');
		if (letters.size() == 6 && letters.get(2) == 'c' && letters.get(3) == 'e') {
			System.out.println("Yay 3");
		}

		for (Character i : letters) {
			System.out.println(i);
		}
		
		if (letters.remove(3) == 'e' && letters.size() == 5 && letters.get(3) == 'g') {
			System.out.println("Yay 4");
		}
	}

	// -------------------------------------------------------------
	// DO NOT EDIT ANYTHING BELOW THIS LINE EXCEPT TO ADD JAVADOCS
	// -------------------------------------------------------------

	// bad practice to have public inst. variables, but we want to test this...
	public DoubleNode<T> head = null;

	// provided doubly-linked list node class
	// bad practice to have public inst. variables,
	// in a public nested class, but we want to test this...
	public static class DoubleNode<T> {
		public T value;

		public DoubleNode<T> next;
		public DoubleNode<T> prev;

		public DoubleNode() {
		}

		public DoubleNode(T value) {
			this.value = value;
		}
	}

	// provided toString() method
	public String toString() {
		StringBuilder sBuilder = new StringBuilder("");
		for (T value : this) {
			sBuilder.append(value);
			sBuilder.append(" ");
		}
		return sBuilder.toString();
	}

	// provided iterator, if your code is working, this should
	// work too...
	public Iterator<T> iterator() {
		return new Iterator<T>() {
			DoubleNode<T> current = head;

			public T next() {
				if (!hasNext())
					throw new NoSuchElementException();
				T val = current.value;
				current = current.next;
				return val;
			}

			public boolean hasNext() {
				return (current != null);
			}
		};
	}
}