// Class for a binary search tree implementation.

/**
 * Creates a simple binary search tree.
 * @author Riley Payung
 * 
 * CS 310
 *
 */
class SimpleBST<T extends Comparable<T>> {

	// -------------------------------------------------------------
	// DO NOT EDIT ANYTHING FOR THIS SECTION EXCEPT TO ADD JAVADOCS
	// -------------------------------------------------------------

	// bad practice to have public inst. variables, but we want to test this...
	// Root of tree
	public Node<T> root;
	/** root of the tree */

	// size of the tree (the number of nodes)
	public int size;

	/** size of the tree */

	/**
	 * returns the size of the tree
	 */
	public int size() {
		return size;
	}

	// provided binary tree node class
	// bad practice to have public inst. variables,
	// in a public nested class, but we want to test this...
	/**
	 * constructor of the Nodes used in the tree.
	 */
	public static class Node<T> {
		T data;
		Node<T> left, right;

		public Node(T data) {
			this.data = data;
		}

		public Node(T data, Node<T> l, Node<T> r) {
			this.data = data;
			this.left = l;
			this.right = r;
		}
	}
	// -------------------------------------------------------------
	// END OF PROVIDED "DO NOT EDIT" SECTION
	// -------------------------------------------------------------

	// -------------------------------------------------------------
	// You can NOT add any instance/static variables in this class.
	// You can add methods if needed but they must be PRIVATE.
	// -------------------------------------------------------------

	// Return true if value is in tree;
	// return false if value is not in tree or if value is null.
	// O(H): H as the tree height
	/**
	 * Makes use of the private contains(node, value) function.
	 * 
	 * O(H)
	 * 
	 * @returns true if the tree contains the specified value, false if not.
	 * 
	 */
	public boolean contains(T value) {

		return contains(root, value);
	}

	/**
	 * Finds out if this contains the value specified
	 * 
	 * O(H)
	 * 
	 * @param node  - root to check.
	 * @param value - value to look for.
	 * 
	 * @returns true if the tree contains the specified value, false if not.
	 * 
	 */
	public boolean contains(Node<T> node, T value) {
		if (node == null || value == null || (node != null && node.data == null)) {
			return false;
		} else {
			for (int i = 0; i < this.toArray().length; i++) {
				if (this.toArray()[i].equals(value)) {
					return true;
				}
			}
		}
		return false;
	}

	// Insert value into tree.
	// No duplicates allowed; no null value allowed.
	// Return false if value cannot be added
	// (duplicate values or null values).
	// Return true for a successful insertion.
	// O(H): H as the tree height

	/**
	 * Inserts a value into this tree.
	 * 
	 * O(N)
	 * 
	 * @param value - value to insert.
	 * @return true if the value is added, false if the value specified is null or
	 *         if the value is duplicated.
	 */
	public boolean insert(T value) {
		if (value == null) {
			return false;
		}
		if (this.contains(value)) {
			return false;
		}
		if (root == null || (root != null && root.data == null)) {
			root = new Node<T>(value);
			size++;
			return true;
		}
		size++;
		this.root = insert(this.root, value);
		return true;
	}

	/**
	 * Inserts a value into this tree.
	 * 
	 * O(H)
	 * 
	 * @param node  - used for recursion.
	 * @param value - value to insert.
	 * @return true if the value is added, false if the value specified is null or
	 *         if the value is duplicated.
	 */
	private Node<T> insert(Node<T> root, T value) {
		if (root == null) {
			root = new Node<T>(value);
			return root;
		}
		if (value.compareTo(root.data) <= -1)
			root.left = insert(root.left, value);
		else if (value.compareTo(root.data) >= 1)
			root.right = insert(root.right, value);
		return root;
	}

	// Remove value from tree.
	// Return false if value cannot be removed
	// (values not in tree or null values)
	// Return true for a successful removal.
	// NOTE: Use predecessor replacement in your implementation.
	// O(H): H as the tree height
	/**
	 * Removes the specified value from the tree.
	 * 
	 * O(H)
	 * 
	 * @param value - value to remove.
	 * @return true if the value was removed, false if not.
	 * 
	 */
	public boolean remove(T value) {
		if (value == null || root == null || (root != null && root.data == null)) {
			return false;
		} else {
			if (remove(root, value) != null) {
				size--;
				return true;
			}
		}
		return false;
	}

	/**
	 * Removes the specified value from the tree.
	 * 
	 * O(H)
	 * 
	 * @param value - value to remove.
	 * @param root  - root node.
	 * @return true if the value was removed, false if not.
	 * 
	 */
	private Node<T> remove(Node<T> root, T value) {
		if (root == null)
			return root;

		if (value.compareTo(root.data) == -1)
			root.left = remove(root.left, value);
		else if (value.compareTo(root.data) == 1)
			root.right = remove(root.right, value);

		else {
			if (root.left == null)
				return root.right;
			else if (root.right == null)
				return root.left;
			if (findPredecessor(root.right) != null)
				root.data = findPredecessor(root.right);
			root.right = remove(root.right, root.data);
		}

		return root;
	}

	// Return the biggest value in the tree rooted at t.
	// Return null if tree is null.
	// O(H): H as the tree height
	/**
	 * finds the max value in the tree.
	 * 
	 * O(H)
	 * 
	 * @param t - node to begin searching from.
	 * @return returns the value at the maximum tree node.
	 * 
	 */
	public static <T> T findMax(Node<T> t) {
		// search all the way to the right.
		if (t.right != null) {
			return findMax(t.right);
		} else {
			return t.data;
		}
	}

	// Remove the biggest value in the binary search tree rooted at t.
	// Return the tree root after removal.
	// Return null for null trees.
	// O(H): H as the tree height
	/**
	 * removes the max value in the tree.
	 * 
	 * O(H)
	 * 
	 * @param t - node to begin searching from.
	 * @return returns the node at the maximum tree node.
	 * 
	 */
	public static <T> Node<T> removeMax(Node<T> t) {
		if (t == null) {
			return null;
		}
		if (t.left != null) {
			return removeMax(t.left);
		}
		if (t.left == null) {
			Node<T> node = t.left;
			t.left = null;
			return node;
		}
		return null;
	}

	// Return the in-order predecessor of t's data in the tree with t as root.
	// This in-order predecessor is the biggest value that is smaller than t's data.
	// Return null if t's data is the smallest or if tree is null.
	// O(H): H as the tree height
	/**
	 * finds the predecessor value in the tree.
	 * 
	 * O(H)
	 * 
	 * @param t - node to begin searching from.
	 * @return returns the value at the pre-order tree node.
	 * 
	 */
	public static <T> T findPredecessor(Node<T> t) {
		// search left.
		if (t == null || (t != null && t.left == null)) {
			return null;
		}
		return t.left.data;
	}

	// Return the height of the tree.
	// Return -1 for null trees.
	// O(N): H as the tree height
	/**
	 * Makes use of the height(node) method to find the height of the tree.
	 * 
	 * O(H)
	 *
	 * @return returns the height of the tree.
	 */
	public int height() {
		if (root == null)
			return -1;
		return height(root) - 1;
	}
	/**
	 * Makes use of the height(node) method to find the height of the tree.
	 * 
	 * O(H)
	 *
	 * @param node - node to search from - root.
	 * @return returns the height of the tree.
	 */
	private int height(Node<T> node) {
		if (node == null) {
			return 0;
		}
		return 1 + Math.max(height(node.left), height(node.right));
	}

	// Return the number of leaf nodes in the tree.
	// Return zero for null trees.
	// NOTE: Your implementation MUST be recursive.
	// O(N): N is the tree size
	/**
	 * Makes use of the numLeaves(node) method to find the total number of leaves.
	 * 
	 * O(H)
	 * 
	 * @return returns the number of leaves.
	 * 
	 * */
	public int numLeaves() {
		if (root == null) {
			return 0;
		}
		return numLeaves(root);
	}
	/**
	 * Makes use of the numLeaves(node) method to find the total number of leaves.
	 * 
	 * O(H)
	 * 
	 * @param node - root node.
	 * @return returns the number of leaves.
	 * 
	 * */
	private int numLeaves(Node<T> node) {
		if (node == null) {
			return 0;
		} else if (node.left == null) {
			return 1;
		} else if (node.right == null) {
			return 1;
		} else {
			return numLeaves(node.left) + numLeaves(node.right);
		}
	}

	// Return a string representation of the tree
	// follow IN-ORDER traversal to include data of all nodes.
	// Include one space after each node.
	// O(N): N is the tree size
	//
	// Return empty string "" for null trees.
	// Check main method below for more examples.
	//
	// Example 1: a single-node tree with the root data as "A":
	// toString() should return "A "
	//
	// Example 2: a tree with three nodes:
	// B
	// / \
	// A C
	// toString() should return "A B C "

	/**
	 * returns a string representation in-order of the tree nodes.
	 * 
	 * @return returns a string representation of the tree.
	 * */
	public String toString() {
		return toString(root);
	}

	private String toString(Node<T> node) {
		StringBuilder build = new StringBuilder();
		if (node == null) {
			return ""; // null tree
		}
		if (node.left != null)
			build.append(toString(node.left));
		build.append(node.data + " ");
		if (node.right != null)
			build.append(toString(node.right));

		return build.toString();
	}

	// Return an array representation of all values
	// following PRE-ORDER traversal.
	// - The root value of the tree should be element 0
	// in the array.
	// - The length of the array should be the size
	// of tree.
	// O(N): N is the tree size
	//
	// Example 1: a single-node tree with the root data as "A"
	// toString() should return {"A"}
	//
	// Example 2: a tree with three nodes:
	// B
	// / \
	// A C
	// toString() should return {"B","A","C"}
	// Check main method below for more examples.

	// @SuppressWarnings("unchecked")
	/**
	 * returns a array representation pre-order of the tree nodes.
	 * 
	 * O(N)
	 * 
	 * @return returns a array representation of the tree.
	 * */
	public Object[] toArray() {
		Object[] array = new Object[size];

		return toArray(array, root);
	}

	private Object[] toArray(Object[] array, Node<T> node) {
		for (int i = 0; i < array.length; i++) {
			if (array[i] == null) {
				array[i] = node.data;
				break;
			}
		}
		if (node.left != null) {
			array = toArray(array, node.left);
		}
		if (node.right != null) {
			array = toArray(array, node.right);
		}
		return array;
	}

	// -------------------------------------------------------------
	// Main Method For Your Testing -- Edit all you want
	// -------------------------------------------------------------
	public static void main(String args[]) {
		SimpleBST<Integer> t = new SimpleBST<Integer>();

		// build the tree / set the size manually
		// only for testing purpose
		Node<Integer> node = new Node<>(112);
		Node<Integer> node2 = new Node<>(330);
		node2 = new Node<>(440, node2, null);
		node = new Node<>(310, node, node2);
		t.root = node;
		t.size = 4;

		// Current tree:
		// 310
		// / \
		// 112 440
		// /
		// 330

		// checking basic features
		if (t.root.data == 310 && t.contains(112) && !t.contains(211) && t.height() == 2) {
			System.out.println("Yay 1");
		}

		// checking more features
		if (t.numLeaves() == 2 && SimpleBST.findMax(t.root) == 440 && SimpleBST.findPredecessor(t.root) == 112) {
			System.out.println("Yay 2");
		}

		// toString and toArray
		if (t.toString().equals("112 310 330 440 ") && t.toArray().length == t.size() && t.toArray()[0].equals(310)
				&& t.toArray()[1].equals(112) && t.toArray()[2].equals(440) && t.toArray()[3].equals(330)) {
			System.out.println("Yay 3");
			// System.out.println(t.toString());
		}

		// start w/ an empty tree and insert to build the same tree as above
		t = new SimpleBST<Integer>();
		if (t.insert(310) && !t.insert(null) && t.size() == 1 && t.height() == 0 && t.insert(112) && t.insert(440)
				&& t.insert(330) && !t.insert(330)) {
			System.out.println("Yay 4");
		}

		if (t.size() == 4 && t.height() == 2 && t.root.data == 310 && t.root.left.data == 112
				&& t.root.right.data == 440 && t.root.right.left.data == 330) {
			System.out.println("Yay 5");
		}

		// more insertion
		t.insert(465);
		t.insert(321);
		t.insert(211);

		// 310
		// / \
		// 112 440
		// \ / \
		// 211 330 465
		// /
		// 321

		// remove leaf (211), after removal:
		// 310
		// / \
		// 112 440
		// / \
		// 330 465
		// /
		// 321

		if (t.remove(211) && !t.contains(211) && t.size() == 6 && t.height() == 3
				&& SimpleBST.findMax(t.root.left) == 112) {
			System.out.println("Yay 6");
		}

		// remove node w/ single child (330), after removal:
		// 310
		// / \
		// 112 440
		// / \
		// 321 465

		if (t.remove(330) && !t.contains(330) && t.size() == 5 && t.height() == 2 && t.root.right.left.data == 321) {
			System.out.println("Yay 7");
		}

		// remove node w/ two children (440), after removal:
		// 310
		// / \
		// 112 321
		// \
		// 465

		if ((t.root != null) && SimpleBST.findPredecessor(t.root.right) == 321 && t.remove(440) && !t.contains(440)
				&& t.size() == 4 && t.height() == 2 && t.root.right.data == 321) {
			System.out.println("Yay 8");
		}

	}

}
