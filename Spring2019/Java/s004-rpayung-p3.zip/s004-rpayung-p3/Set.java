
// for addAll() only
import java.util.Collection;

// A Set using HashTable.
/**
 * Creates a set using HashTable. Storage of 5 elements initially. Has all the
 * functionality of a set.
 * 
 * @author Riley Payung
 * 
 *         CS 310
 *
 */
class Set<T extends Comparable<T>> {

	// -------------------------------------------------------------
	// DO NOT EDIT ANYTHING FOR THIS SECTION EXCEPT TO ADD JAVADOCS
	// -------------------------------------------------------------
	/** Inital HashTable with size 5. */
	private HashTable<T> storage = new HashTable<>(5);

	/**
	 * Return the number of values in set.
	 * 
	 * O(1)
	 * 
	 * @return size of the storage.
	 */
	public int size() {
		return storage.size();
	}

	/**
	 * If value not present in set, add value and return true. Otherwise, do not add
	 * and return false.
	 * 
	 * O(N)
	 * 
	 * @param value - value to add.
	 * @return true if the value was added. false if not.
	 * 
	 */
	public boolean add(T value) {
		return storage.add(value);
	}

	/**
	 * checks to see if a value specified is in the set.
	 * 
	 * O(N)
	 * 
	 * @param value - value to search for.
	 * @return returns true if the value is contained in the set, false if not.
	 * 
	 */
	public boolean contains(T value) {
		return storage.contains(value);
	}

	// If value present in set, remove value and return true.
	// Otherwise return false and no change to set.
	/**
	 * Removes the value specified from the set.
	 * 
	 * O(N)
	 * 
	 * @param value - value to remove.
	 * @return true if the value is removed. false if not.
	 */
	public boolean remove(T value) {
		return storage.remove(value);
	}

	/**
	 * Returns a string representation of the set.
	 */
	public String toString() {
		return storage.toString();
	}

	/**
	 * Returns an array representation of the set.
	 */
	public Object[] toArray() {
		return storage.toArray();
	}

	// -------------------------------------------------------------
	// END OF PROVIDED "DO NOT EDIT" SECTION
	// -------------------------------------------------------------

	// -------------------------------------------------------------
	// You can NOT add any instance/static variables in this class.
	// You can add methods if needed but they must be PRIVATE.
	// -------------------------------------------------------------

	// Accept a collection of values and add them into set
	// one by one. Follow the order as provided by the
	// .iterator() of the collection to add.
	// Return the number of values successfully added.
	/**
	 * Accepts a collection of objects to add to the storage of this set.
	 * 
	 * O(N)
	 * 
	 * @param c - collection to add.
	 * @return returns the number of successful adds.
	 */
	public int addAll(Collection<T> c) {
		int num = 0;
		for (T i : c)
			if (storage.add(i))
				num++;
		return num;
	}

	// Construct and return the intersection set of this and other.
	// Intersection set should include all values
	// that are in both this set and other.
	// Original sets should not be modified.
	@SuppressWarnings("unchecked")
	/**
	 * Constructs and returns an intersection of the set and another set.
	 * 
	 * O(N)
	 * 
	 * @param other - another set to intersect.
	 * @return new set of values that were contained in both this set and the other
	 *         set.
	 * 
	 */
	public Set<T> intersection(Set<T> other) {
		Set<T> newSet = new Set<T>();
		int bigger = other.size();
		boolean otherBigger = true;
		if (bigger < size()) {
			bigger = size();
			otherBigger = false;
		}
		for (int i = 0; i < bigger; i++) {
			if (!otherBigger) {
				if (other.contains((T) toArray()[i])) {
					newSet.add((T) toArray()[i]);
				}
			} else {
				if (contains((T) other.toArray()[i])) {
					newSet.add((T) other.toArray()[i]);
				}
			}
		}

		return newSet;
	}

	// Construct and return the union set of this and other.
	// Union set should include all values
	// that belongs to at least one of this set and other.
	// Original sets should not be modified.
	@SuppressWarnings("unchecked")
	/**
	 * Constructs and returns an union of the set and another set.
	 * 
	 * O(N)
	 * 
	 * @param other - another set to union.
	 * @return new set of values that were contained in both this set or the other
	 *         set.
	 * 
	 */
	public Set<T> union(Set<T> other) {
		Set<T> newSet = new Set<T>();

		int sizeOf = other.size() + this.size();

		for (int i = 0; i < sizeOf; i++) {
			if (i < size()) {
				newSet.add((T) toArray()[i]);
			} else {
				newSet.add((T) other.toArray()[i - size()]);
			}
		}

		return newSet;
	}

	// Construct and return the difference set: this - other.
	// Result should include all values in this set
	// but not in other.
	// Original sets should not be modified.
	@SuppressWarnings("unchecked")
	/**
	 * Constructs and returns a difference set of the set and another set.
	 * 
	 * O(N)
	 * 
	 * @param other - another set to difference.
	 * @return new set of values of the subtraction of another set from this set.
	 * 
	 */
	public Set<T> difference(Set<T> other) {
		Set<T> newSet = new Set<T>();
		int bigger = other.size();
		boolean otherBigger = true;
		if (bigger < size()) {
			bigger = size();
			otherBigger = false;
		}
		for (int i = 0; i < bigger; i++) {
			if (otherBigger) {
				if (!contains((T) other.toArray()[i])) {
					newSet.add((T) other.toArray()[i]);
				}
			} else {
				if (!other.contains((T) toArray()[i])) {
					newSet.add((T) toArray()[i]);
				}
			}
		}

		return newSet;
	}

	// Construct and return the symmetric difference set.
	// Result should include all values in exactly
	// one set of this set and other but not both.
	// Original sets should not be modified.
	@SuppressWarnings("unchecked")
	/**
	 * Constructs and returns a set built to hold values from either sets but not
	 * both.
	 * 
	 * O(N)
	 * 
	 * @param other - another set to symmetrically subtract.
	 * @return new set of values that were contained contained in either set, but
	 *         not both.
	 * 
	 */
	public Set<T> symmetricDifference(Set<T> other) {
		Set<T> newSet = new Set<T>();

		int sizeOf = other.size() + this.size(); // size of both.

		for (int i = 0; i < sizeOf; i++) {
			if (i < size()) {
				if (!other.contains((T) toArray()[i])) {
					newSet.add((T) toArray()[i]);
				}
			} else {
				if (!contains((T) other.toArray()[i - size()])) {
					newSet.add((T) other.toArray()[i - size()]);
				}
			}
		}

		return newSet;
	}

	// Return true if this set is a subset of other,
	// return false otherwise.
	@SuppressWarnings("unchecked")
	/**
	 * Returns whether or not this set is a subset of another set.
	 * 
	 * O(N)
	 * 
	 * @param other - set to check is a subset of.
	 * @return true if the set is a subset of another, false if not.
	 */
	public boolean isSubset(Set<T> other) {
		int num = 0;
		for (int i = 0; i < other.size(); i++) {
			if (this.contains((T) other.toArray()[i])) {
				num++;
			}
		}

		if (this.size() == num) {
			return true;
		}

		return false;
	}

	// Return true if there is no overlap between
	// this set and other; return false otherwise.
	@SuppressWarnings("unchecked")
	/**
	 * Checks for any overlapping values in a set to check if disjoint. No values
	 * may match in either set.
	 * 
	 * O(N)
	 * 
	 * @param other - set to check if disjoint.
	 * @return true if there are no duplicate values, false if there is.
	 * 
	 */
	public boolean isDisjoint(Set<T> other) {
		int num = 0;

		for (int i = 0; i < other.size(); i++) {
			if (this.contains((T) other.toArray()[i])) {
				num++;
			}
		}

		if (num == 0) {
			return true;
		}
		return false;
	}

	// -------------------------------------------------------------
	// Main Method For Your Testing -- Edit all you want
	// -------------------------------------------------------------

	public static void main(String args[]) {
		// arrays only used for testing here
		Integer[] data1 = { 1, 2, 3, 5, 7 };
		Integer[] data2 = { 2, 4, 5, 6 };
		String[] duplicate = { "a", "a", "a", "b", "c", "b", "c", "d", "a", "e", "c", "b" };
		Set<Integer> set1 = new Set<>();
		Set<Integer> set2 = new Set<>();
		Set<String> noduplicate = new Set<>();

		// addAll
		if (set1.addAll(java.util.Arrays.asList(data1)) == 5 && set2.addAll(java.util.Arrays.asList(data2)) == 4
				&& noduplicate.addAll(java.util.Arrays.asList(duplicate)) == 5) {
			System.out.println("Yay 1");
		}

		// System.out.println(set1);
		// System.out.println(set2);

		Set<Integer> set3 = set1.intersection(set2);
		// System.out.println(set3); //should have 2 and 5 only
		if (set3.contains(2) && set3.contains(5) && !set3.contains(1) && set3.size() == 2) {
			System.out.println("Yay 2");
		}

		Set<Integer> set4 = set1.union(set2);
		// System.out.println(set4); //should have 1,2,3,4,5,6,7 (not necessarily in
		// that order)
		boolean ok = true;
		for (int i = 1; i < 8; i++) {
			ok = ok && set4.contains(i);
		}
		if (ok && set4.size() == 7) {
			System.out.println("Yay 3");
		}

		Set<Integer> set5 = set1.difference(set2);
		// System.out.println(set5); //should have 1,3,7 (unordered)
		if (set5.size() == 3 && set5.contains(1) && set5.contains(3) && set5.contains(7) && !set5.contains(2)
				&& !set5.contains(5) && !set5.contains(4)) {
			System.out.println("Yay 4");
		}

		@SuppressWarnings("unused")
		Set<Integer> set6 = set1.symmetricDifference(set2);
		// System.out.println("set 6: " + set6); // should have 1,3,4,6,7 (unordered)

		if (!set1.isSubset(set2) && set3.isSubset(set2) && !set1.isDisjoint(set2) && set5.isDisjoint(set2)) {
			System.out.println("Yay 5");
		}

	}

}