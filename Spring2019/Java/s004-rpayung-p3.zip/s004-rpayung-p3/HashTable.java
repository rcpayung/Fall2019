// A hash table implemented with separate chaining.

// Every chain is organized as a binary search tree.


// imports for debugging only
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.File;
import java.io.IOException;
import java.util.Random;
/**
 * Creates a HashTable with rehashing and hashing.
 * @author Riley Payung
 * 
 * CS 310
 *
 */
class HashTable<T extends Comparable<T>> {

	// -------------------------------------------------------------
	// DO NOT EDIT ANYTHING FOR THIS SECTION EXCEPT TO ADD JAVADOCS
	// -------------------------------------------------------------

	/** minimum length */
	static private int minLength = 2;

	/** the size of the hashtable (number of total elements) */
	private int size = 0;
	/** storage of hashed trees */
	private SimpleBST<T>[] storage;

	// Return the table length.
	/**
	 * Gets the Length of the hashtable.
	 * 
	 * @return returns storage length.
	 */
	public int getLength() {
		return storage.length;
	}

	// Return the number of values in hash table.
	/**
	 * Returns the number of elements in the hashtable.
	 */
	public int size() {
		return size;
	}

	// Return a string representation of all values in hash table.
	/**
	 * Returns string representation of the hashtable.
	 */
	public String toString() {
		StringBuilder s = new StringBuilder();
		for (int i = 0; i < storage.length; i++) {
			if (storage[i] != null) {
				s.append(storage[i].toString());
			}
		}
		return s.toString().trim();
	}

	// Return a detailed string representation of the hash table.
	// Give the contents of each table entry.
	// Verbose mode: a detailed report of tree features for every entry.
	/**
	 * Returns a debug version of the table.
	 * 
	 * @param verbose - adds more information if true.
	 */
	public String toStringDebug(boolean verbose) {
		StringBuilder s = new StringBuilder();
		for (int i = 0; i < storage.length; i++) {
			if (storage[i] != null && storage[i].size() != 0) {
				s.append("[" + i + "]: " + storage[i].toString().trim() + "\n");
				if (verbose) {
					s.append("\t tree size:" + storage[i].size() + "\n");
					s.append("\t tree height:" + storage[i].height() + "\n");
					s.append("\t number of leaves:" + storage[i].numLeaves() + "\n");
				}
			} else
				s.append("[" + i + "]: null\n");

		}
		return s.toString().trim();
	}

	// -------------------------------------------------------------
	// END OF PROVIDED "DO NOT EDIT" SECTION
	// -------------------------------------------------------------

	// -------------------------------------------------------------
	// You can NOT add any instance/static variables in this class.
	// You can add methods if needed but they must be PRIVATE.
	// -------------------------------------------------------------

	// Constructor.
	// Make sure the table is initialized with given length.
	// Use minLength to initialize table if given length goes below that.
	@SuppressWarnings("unchecked")
	/**
	 * HashTable Constructor - Checks for illegal arguments.
	 * 
	 * @param length - length specified
	 */
	public HashTable(int length) {
		if (length < this.minLength) {
			this.storage = new SimpleBST[minLength];
			return;
		}
		this.storage = new SimpleBST[length];
	}

	// Add value into hash table.
	// - Use separate chaining for collision.
	// - Return false if value cannot be added
	// (duplicate values or null values).
	// - Return true for a successful insertion.
	// - After adding a new value, if the table
	// has a load>= 80%, rehash the table to twice
	// the size.
	//
	// Worst case: O(N), Average case: O(load)
	// - N as the number of values in hash table
	// - not considering rehashing overhead

	/**
	 * Adds a value to the hashtable. Uses seperate chaining, each hash index is a
	 * SimpleBST. Automatically rehashes if the load factor is 0.8 or greater.
	 * 
	 * O(N)
	 * 
	 * @param value - Insertion value.
	 * @return true if the value was added, false if not or value is null.
	 */
	public boolean add(T value) {
		if (value == null)
			return false;
		int hashCode = Math.abs(value.hashCode());
		double load = (double) size() / (double) getLength();
		if (storage[hashCode % getLength()] == null) {
			storage[hashCode % getLength()] = new SimpleBST<>();
		} else {
			if (storage[hashCode % getLength()].contains(value))
				return false;
		}
		storage[hashCode % getLength()].insert(value);
		size++;
		load = (double) size() / (double) getLength();
		if (load >= 0.8) {
			rehash(getLength() * 2);
		}
		return true;
	}

	// Check whether value is in hash table.
	// - Return true is present, false otherwise
	// Worst case: O(N), Average case: O(load)
	// - N as the number of values in hash table
	/**
	 * Checks if the table contains the specified value.
	 * 
	 * O(N)
	 * 
	 * @param value - value to search for.
	 * @return true if the value is in the table. false if not or if value is null.
	 * 
	 */
	public boolean contains(T value) {
		if (value == null)
			return false;
		for (int i = 0; i < storage.length; i++) {
			if (storage[i] != null)
				if (storage[i].contains(value)) {
					return true;
				}
		}
		return false;
	}

	// Remove and return true if value is in hash table.
	// Return false if value cannot be removed
	// (values not in tree or null values)
	// Worst case: O(N), Average case: O(load)
	// - N as the number of values in hash table
	/**
	 * Removes a value from the table of the specified value.
	 * 
	 * O(N)
	 * 
	 * @param value - value to search for.
	 * @return true if the value is removed from the table. false if not or if value
	 *         is null.
	 * 
	 */
	public boolean remove(T value) {
		if (value == null)
			return false;
		for (int i = 0; i < storage.length; i++) {
			if (storage[i] != null)
				if (storage[i].contains(value)) {
					storage[i].remove(value);
					size--;
					return true;
				}
		}
		return false;
	}

	// Rehash hash table to newLength.
	// - This can be used to increase or decrease the
	// capacity of the storage.
	// - If the new capacity won't fit all the elements,
	// return false and do not rehash.
	// - If the new capacity is smaller than minLength,
	// return false and do not rehash.
	// - Return true if you were able to rehash.
	// - If you are asked to rehash to a length such that
	// the load would be >= 0.8, double the length parameter
	// until the load would be < 0.8 and use that new length.

	// All values should be rehashed following this order:
	// - Hash table entries should be rehashed based on array index
	// in ascending order.
	// - Multiple values in a chain (i.e. a binary search tree)
	// should be rehashed in pre-order.
	// (Hint: consider .toArray() in SimpleBST class)

	// O(N+M): N as the number of values in hash table;
	// M as the table length.

	@SuppressWarnings("unchecked")
	/**
	 * Rehashes the table to twice the size. adds the values to a temporary array
	 * and moves them from the array to the newly hashed table.
	 * 
	 * O(N+M)
	 * 
	 * @param newLength - the length to create the new hashtable to.
	 * @return true if the table was rehashed, false if the new length is less than
	 *         the current length.
	 * 
	 */
	public boolean rehash(int newLength) {
		if (newLength < getLength()) {
			return false;
		}

		Object[] data = toArray();
		this.storage = new SimpleBST[newLength];
		this.size = 0;

		for (int i = 0; i < data.length; i++) {
			add((T) data[i]);
		}

		return true;
	}

	// Return an array representation of all value in hash table.
	// The array should be assembled following this order:
	// - Hash table entries should be checked based on array index
	// in ascending order.
	// - Multiple values in a chain (i.e. a binary search tree)
	// should be rehashed in pre-order.
	// (Hint: consider .toArray() in SimpleBST class)
	// The array length should be the same as number of values in hash table.
	//
	// O(N+M): N as the number of values in hash table;
	// M as the table length.
	/**
	 * Returns an array representation of the hashtable in pre-order.
	 * 
	 * O(N^2)
	 * 
	 * @return array representation of the hashtable.
	 * 
	 */
	public Object[] toArray() {
		Object[] array = new Object[size];
		int index = 0;

		for (SimpleBST<T> i : storage) {
			if (i != null)
				for (Object j : i.toArray()) {
					array[index] = j;
					index++;
				}
		}

		return array;
	}

	/**
	 * Return the average tree height. - If nonEmptyOnly is true, only consider
	 * non-empty trees; otherwise all trees are considered. - Return -1.0 if all
	 * trees are empty but only non-empty trees are considered
	 * 
	 * O(N)
	 * 
	 * @param nonEmptyOnly - Check for non-empty chains or the entire table.
	 * @return returns the average height divided by the length or the number of
	 *         active chains.
	 */
	public double avgTreeHeight(boolean nonEmptyOnly) {
		double avSize = 0.0;
		int numOfChains = 0;

		if (nonEmptyOnly) {
			for (int i = 0; i < storage.length; i++) {
				if (storage[i] != null || (storage[i] != null && storage[i].size() != 0)) {
					avSize += (double) storage[i].height();
					numOfChains++;
				}
			}
			return avSize / (double) numOfChains;
		} else {
			for (int i = 0; i < storage.length; i++) {
				if (storage[i] != null) {
					avSize += (double) storage[i].height();
				}
			}
			return avSize / (double) getLength();
		}
	}

	/**
	 * Return the average tree size. - If nonEmptyOnly is true, only consider
	 * non-empty trees; otherwise all trees are considered. - Return 0.0 if all
	 * trees are empty but only non-empty trees are considered
	 * 
	 * O(N)
	 * 
	 * @param nonEmptyOnly - Check for non-empty chains or the entire table.
	 * @return returns the average size divided by the length or the number of
	 *         active chains.
	 */
	public double avgTreeSize(boolean nonEmptyOnly) {
		double avSize = 0.0;
		int numOfChains = 0;

		if (nonEmptyOnly) {
			for (int i = 0; i < storage.length; i++) {
				if (storage[i] != null || (storage[i] != null && storage[i].size() != 0)) {
					avSize += (double) storage[i].size();
					numOfChains++;
				}
			}
			return avSize / (double) numOfChains;
		} else {
			for (int i = 0; i < storage.length; i++) {
				if (storage[i] != null) {
					avSize += (double) storage[i].size();
				}
			}
			return avSize / (double) getLength();
		}
	}

	/**
	 * Return the average number of leaves. - If nonEmptyOnly is true, only consider
	 * non-empty trees; otherwise all trees are considered. - Return 0.0 if all
	 * trees are empty but only non-empty trees are considered
	 * 
	 * O(N)
	 * 
	 * @param nonEmptyOnly - Check for non-empty chains or the entire table.
	 * @return returns the average number of leaves divided by the length or the
	 *         number of active chains.
	 */
	public double avgNumLeaves(boolean nonEmptyOnly) {
		double avSize = 0.0;
		int numOfChains = 0;

		if (nonEmptyOnly) {
			for (int i = 0; i < storage.length; i++) {
				if (storage[i] != null || (storage[i] != null && storage[i].size() != 0)) {
					avSize += (double) storage[i].numLeaves();
					numOfChains++;
				}
			}
			return avSize / (double) numOfChains;
		} else {
			for (int i = 0; i < storage.length; i++) {
				if (storage[i] != null) {
					avSize += (double) storage[i].numLeaves();
				}
			}
			return avSize / (double) getLength();
		}
	}

	/**
	 * Return the min and max tree size as a pair.
	 * 
	 * O(N)
	 * 
	 * @return returns a pair representation of the minimum and maximum tree size.
	 */
	public Pair<Integer, Integer> minAndMaxTreeSize() {
		// pair with of the tree with the smallest size and the tree with the largest
		// size.
		int sizeMin = 0;
		int sizeMax = 0;

		for (int i = 0; i < storage.length; i++) {
			if (storage[i] != null) {
				if (sizeMax < storage[i].size()) {
					sizeMax = storage[i].size();
				}
				if (sizeMin > storage[i].size()) {
					sizeMin = storage[i].size();
				}
			}
		}
		if (sizeMin == sizeMax) {
			sizeMin = -1;
		}
		return new Pair<Integer, Integer>(sizeMin, sizeMax);
	}

	/**
	 * Return the min and max tree height as a pair.
	 * 
	 * O(N)
	 * 
	 * @return returns a pair representation of the minimum and maximum tree height.
	 */
	public Pair<Integer, Integer> minAndMaxTreeHeight() {
		int sizeMin = 0;
		int sizeMax = 0;

		for (int i = 0; i < storage.length; i++) {
			if (storage[i] != null) {
				if (sizeMax < storage[i].height()) {
					sizeMax = storage[i].height();
				}
				if (sizeMin > storage[i].height()) {
					sizeMin = storage[i].height();
				}
			}
		}
		if (sizeMin == 0) {
			sizeMin = -1;
		}
		return new Pair<Integer, Integer>(sizeMin, sizeMax);
	}

	/**
	 * Return the min and max number of leaves in trees as a pair.
	 * 
	 * O(N)
	 * 
	 * @return returns a pair representation of the minimum and maximum tree number
	 *         of leaves.
	 */
	public Pair<Integer, Integer> minAndMaxNumLeaves() {
		int sizeMin = 0;
		int sizeMax = 0;

		for (int i = 0; i < storage.length; i++) {
			if (storage[i] != null) {
				if (sizeMax < storage[i].numLeaves()) {
					sizeMax = storage[i].numLeaves();
				}
				if (sizeMin > storage[i].numLeaves()) {
					sizeMin = storage[i].numLeaves();
				}
			}
		}
		if (sizeMin == sizeMax) {
			sizeMin = -1;
		}
		return new Pair<Integer, Integer>(sizeMin, sizeMax);
	}

	// -------------------------------------------------------------
	// Main Method For Your Testing -- Edit all you want
	// -------------------------------------------------------------

	public static void main(String[] args) {
		BufferedWriter writer = null;
		boolean debug = false;

		try {
			if (args.length == 1 && args[0].equals("-debug")) {
				writer = new BufferedWriter(new FileWriter(new File("debug.txt")));
				debug = true;
			}

			HashTable<String> ht1 = new HashTable<>(10);

			// empty hash table
			if (ht1.getLength() == 10 && ht1.size() == 0 && ht1.toString().equals("")) {
				System.out.println("Yay 1");
			}

			// add
			if (ht1.add("a") && ht1.add("c") && ht1.add("computer") && !ht1.add("c") && ht1.getLength() == 10
					&& ht1.size() == 3) {
				System.out.println("Yay 2");
			}
			// hashCode() references:
			// "a": 97, "c": 99, "computer": -599163109

			// basic features of hash table
			if (ht1.contains("a") && ht1.contains("computer") && ht1.contains("c") && !ht1.contains("cs")
					&& ht1.toString().equals("a c computer") && ht1.toStringDebug(false).equals(
							"[0]: null\n[1]: null\n[2]: null\n[3]: null\n[4]: null\n[5]: null\n[6]: null\n[7]: a\n[8]: null\n[9]: c computer")) {
				System.out.println("Yay 3");
			}
			// System.out.println(ht1.toStringDebug(true));

			if (debug) {
				writer.write(
						"=====================================================" + System.getProperty("line.separator"));
				writer.write(
						"ht1 after add(\"a\"), add(\"c\"), add(\"computer\")" + System.getProperty("line.separator"));
				writer.write(
						"-----------------------------------------------------" + System.getProperty("line.separator"));
				writer.write(ht1.toStringDebug(true) + System.getProperty("line.separator")
						+ System.getProperty("line.separator"));
			}

			// remove
			if (!ht1.remove("data") && ht1.remove("c") && ht1.size() == 2 && !ht1.contains("c") // problem with removing
																								// c;
					&& ht1.contains("computer")) {
				System.out.println("Yay 4");

			}

			// rehash
			HashTable<Integer> ht2 = new HashTable<>(5);
			ht2.add(105);
			ht2.add(26);
			ht2.add(11);
			if (ht2.getLength() == 5 && ht2.size() == 3 && ht2.add(55) && ht2.getLength() == 10 && ht2.add(5)
					&& ht2.add(-11) && ht2.add(31) && ht2.getLength() == 10 && ht2.size() == 7) {
				System.out.println("Yay 5");
			}

			// System.out.println(ht2.toString());
			// System.out.println(ht2.toStringDebug(true));
			if (debug) {
				writer.write(
						"=====================================================" + System.getProperty("line.separator"));
				writer.write("ht2 after adding these in order: 105, 26, 11, 55, 5, -11, 31"
						+ System.getProperty("line.separator"));
				writer.write(
						"-----------------------------------------------------" + System.getProperty("line.separator"));
				writer.write(ht2.toStringDebug(true) + System.getProperty("line.separator")
						+ System.getProperty("line.separator"));
			}

			if (ht2.toString().equals("-11 11 31 5 55 105 26") && ht2.size() == 7 && ht2.toStringDebug(false).equals(
					"[0]: null\n[1]: -11 11 31\n[2]: null\n[3]: null\n[4]: null\n[5]: 5 55 105\n[6]: 26\n[7]: null\n[8]: null\n[9]: null")) {
				System.out.println("Yay 6");
			}

			// tree features from hash table
			if (ht2.avgTreeSize(false) == 0.7 && ht2.avgTreeSize(true) == 7.0 / 3
					&& ht2.avgTreeHeight(false) == -4.0 / 10 && ht2.avgTreeHeight(true) == 1
					&& ht2.avgNumLeaves(false) == 0.4 && ht2.avgNumLeaves(true) == 4.0 / 3) {
				System.out.println("Yay 7");
			}

			// more tree features
			if (ht2.minAndMaxTreeSize().toString().equals("<0,3>")
					&& ht2.minAndMaxTreeHeight().toString().equals("<-1,2>")
					&& ht2.minAndMaxNumLeaves().toString().equals("<0,2>")) {
				System.out.println("Yay 8");
			}

			// more rehash
			if (ht2.rehash(2) == false && ht2.size() == 7 && ht2.getLength() == 10) {
				System.out.println("Yay 9");
			}

			if (ht2.rehash(11) == true && ht2.size() == 7 && ht2.getLength() == 11) {
				System.out.println("Yay 10");
			}
			// System.out.println(ht2.toString());
			// System.out.println(ht2.toStringDebug(true));

			if (debug) {
				writer.write(
						"=====================================================" + System.getProperty("line.separator"));
				writer.write("ht2 after rehash to length 11" + System.getProperty("line.separator"));
				writer.write(
						"-----------------------------------------------------" + System.getProperty("line.separator"));
				writer.write(ht2.toStringDebug(true) + System.getProperty("line.separator")
						+ System.getProperty("line.separator"));

				// bigger hashtable w/ major clusterings
				HashTable<Integer> ht3 = new HashTable<>(20);
				ht3.add(160);
				ht3.add(20);
				ht3.add(100);
				ht3.add(80);
				ht3.add(400);
				ht3.add(280);
				ht3.add(640);

				ht3.add(543);
				ht3.add(3);
				ht3.add(283);
				ht3.add(343);
				ht3.add(443);

				ht3.add(334);
				ht3.add(974);
				ht3.add(454);

				writer.write(
						"=====================================================" + System.getProperty("line.separator"));
				writer.write("ht3 of 15 values clustered into three trees" + System.getProperty("line.separator"));
				writer.write(
						"-----------------------------------------------------" + System.getProperty("line.separator"));
				writer.write(ht3.toStringDebug(true) + System.getProperty("line.separator")
						+ System.getProperty("line.separator"));

				// bigger hashtable w/ uniform distribution
				ht3 = new HashTable<>(20);
				int count = 0;
				Random r = new Random(0);
				while (count < 15) {
					if (ht3.add(r.nextInt(1000)))
						count++;
				}
				writer.write(
						"=====================================================" + System.getProperty("line.separator"));
				writer.write("ht3 of 15 values uniformly distributed" + System.getProperty("line.separator"));
				writer.write(
						"-----------------------------------------------------" + System.getProperty("line.separator"));
				writer.write(ht3.toStringDebug(true) + System.getProperty("line.separator"));

			}
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				if (writer != null)
					writer.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

	}

}