/**
 * Builds an array that automatically changes based on the size of elements. 
 * I built this as an ArrayList implementation
 * <p>
 * @author Riley Payung
 * <p>
 * CS310
 * Spring 2019
 */

public class SmartArray<T> {

	private static final int DEFAULT_CAPACITY = 2; // default initial capacity / minimum capacity
	private T[] data; // underlying array

	// ADD MORE PRIVATE MEMBERS HERE IF NEEDED!
	private int size = 0;

	/**
	 * Sets up a new SmartArray of the default capacity.
	 */
	@SuppressWarnings("unchecked")
	public SmartArray() {
		// constructor
		// initial capacity of the array should be DEFAULT_CAPACITY
		data = (T[]) new Object[DEFAULT_CAPACITY];
	}

	/**
	 * Sets up a new SmartArray of a specified capacity.
	 * 
	 * @param initialCapacity Overrides the default constructor to build an array of
	 *                        a specified initial capacity
	 * @throws IllegalArgumentException value of initialCapacity cannot be less than
	 *                                  1.
	 */
	@SuppressWarnings("unchecked")
	public SmartArray(int initialCapacity) {
		if (initialCapacity < 1) {
			throw new IllegalArgumentException();
		}

		data = (T[]) new Object[initialCapacity];
	}

	/**
	 * report number of elements in the smart array
	 * 
	 * O(1)
	 * 
	 * @return the number of elements in the array.
	 */
	public int size() {
		return this.size;
	}

	/**
	 * report max number of elements before the next expansion
	 * 
	 * O(1)
	 * 
	 * @return the length of the array
	 */
	public int capacity() {
		return this.data.length;
	}

	/**
	 * This method adds the given value at the given index. The method will
	 * automatically shift objects to the right when needed. The method will also
	 * double the capacity of the array when needed.
	 * 
	 * O(N)
	 * 
	 * @param index inserts at the given index
	 * @param value inserts the value at the given index provided that the index is
	 *              within the capacity of the array.
	 * @throws IndexOutOfBoundsException
	 * @see notInvalidIndex(int index)
	 */
	public void add(int index, T value) {
		if (size() == capacity()) {
			ensureCapacity(capacity() * 2);
		}
		if (!notInvalidIndex(index)) {
			return;
		}

		T copy = null, next = null;

		for (int i = index; i < capacity(); i++) {
			if (i == index && this.data[i] == null) {
				this.data[i] = value;
				size++;
				break;
			} else if (i == index && this.data[i] != null) {
				copy = this.data[i];
				this.data[i] = value;
				size++;
				continue;
			}
			if (copy != null && this.data[i] != null) {
				next = this.data[i];
				this.data[i] = copy;
				copy = next;
				next = null;
			} else {
				this.data[i] = copy;
			}
		}
	}

	/**
	 * Private modular function to check for invalid index (Reused multiple times
	 * throughout class)
	 * 
	 * O(1)
	 * 
	 * @param index index to check
	 * @throws throws an {@link IndexOutOfBoundsException} if the index is less than
	 *                0 or greater than the capacity of the array
	 * @return true if the function does not throw an exception.
	 */
	private boolean notInvalidIndex(int index) {
		if (index < 0 || index > this.capacity()) {
			throw new IndexOutOfBoundsException();
		} else
			return true;
	}

	/**
	 * Returns the value at the given index.
	 * 
	 * O(1)
	 * 
	 * @param index index to get the value from
	 * @return returns the value at the given index.
	 * @throws IndexOutOfBoundsException
	 * @see notInvalidIndex(int Index)
	 */
	public T get(int index) {
		if (notInvalidIndex(index))
			return data[index];
		return null;
	}

	/**
	 * This function replaces the value of the data at a specified index.
	 * 
	 * O(1)
	 * 
	 * @param index index to find to replace the value at
	 * @param value value to replace at the given index.
	 * @throws IndexOutOfBoundsException
	 * @see notInvalidIndex(int index)
	 * @return returns the value that was replaced.
	 */
	public T replace(int index, T value) {
		T copy = null;
		if (notInvalidIndex(index)) {
			copy = this.data[index];
			this.data[index] = value;
		}
		return copy;
	}

	/**
	 * Deletes the value at the given index. Also ensures the capacity is shortened
	 * when only (1/4)th of the capacity of the array actually contains values.
	 * 
	 * O(N)
	 * 
	 * @param index the index to be deleted
	 * @throws IndexOutOfBoundsException
	 * @see notInvalidIndex(int index)
	 * @return returns the deleted entry from the array.
	 */
	public T delete(int index) {
		T delEntry = null;
		if (notInvalidIndex(index)) {
			for (int i = 0; i < this.capacity(); i++) {
				if (i >= index && i < this.capacity() - 1) {
					if (i == index) {
						delEntry = this.data[i];
						size--;
					}
					this.data[i] = this.data[i + 1];
				}
			}
			if (!(this.capacity() * 0.25 <= DEFAULT_CAPACITY) && this.capacity() * 0.25 >= size()) {
				ensureCapacity(this.capacity() / 2);
			}
		}
		return delEntry;
	}

	/**
	 * Ensures the capacity of the array does not end up too small or too large.
	 * 
	 * O(N)
	 * 
	 * @param newCapacity capacity to either increase or decrease to
	 * @return returns true when the capacity has been set to the parameterized
	 *         value. false if the value is less than the current capacity or is not
	 *         capable of handling the amount of data currently in the array.
	 */
	public boolean ensureCapacity(int newCapacity) {
		// change the max number of items allowed before next expansion to newCapacity

		// capacity should not be changed if:
		// - newCapacity is below DEFAULT_CAPACITY; or
		// - newCapacity is not large enough to accommodate current number of items

		// return true if newCapacity gets applied; false otherwise
		// O(N) where N is the number of elements in the array
		if (newCapacity <= DEFAULT_CAPACITY || newCapacity <= size || newCapacity == this.capacity()) {
			return false;
		}

		@SuppressWarnings("unchecked")
		T[] copy = (T[]) new Object[newCapacity];

		if (copy.length > this.capacity())
			for (int i = 0; i < this.data.length; i++) {

				copy[i] = this.data[i];
			}
		else
			for (int i = 0; i < copy.length; i++) {
				copy[i] = this.data[i];
			}
		this.data = copy;
		return true;
	}

	// --------------------------------------------------------
	// example testing code... edit this as much as you want!
	// --------------------------------------------------------
	public String toString() {

		StringBuilder build = new StringBuilder();

		for (int i = 0; i < size(); i++) {
			if (i < size() - 1 && data[i] != null && (data[i] instanceof String))
				build.append((String) data[i] + ", ");
			if (i < size() && i >= size() - 1)
				build.append((String) data[i]);
		}

		return build.toString();
	}

	public static void main(String args[]) {

		// create a smart array of integers
		SmartArray<Integer> nums = new SmartArray<>();
		if ((nums.size() == 0) && (nums.capacity() == 2)) {
			System.out.println("Yay 1");
		}

		// append some numbers
		for (int i = 0; i < 3; i++)
			nums.add(i, i * 2);

		if (nums.size() == 3 && nums.get(2) == 4 && nums.capacity() == 4) {
			System.out.println("Yay 2");
		}

		// create a smart array of strings
		SmartArray<String> msg = new SmartArray<>();

		// insert some strings
		msg.add(0, "world");
		msg.add(0, "hello");
		msg.add(1, "new");
		msg.add(3, "!");

		// replace and checking
		if (msg.get(0).equals("hello") && msg.replace(1, "beautiful").equals("new") && msg.size() == 4
				&& msg.capacity() == 4) {
			// System.out.println(msg);
			System.out.println("Yay 3");
		}

		// change capacity
		if (!msg.ensureCapacity(0) && !msg.ensureCapacity(3) && msg.ensureCapacity(20) && msg.capacity() == 20) {
			System.out.println("Yay 4");
		}

		// delete and shrinking
		if (msg.delete(1).equals("beautiful") && msg.get(1).equals("world") && msg.size() == 3
				&& msg.capacity() == 10) {
			System.out.println("Yay 5");
		}

		System.out.println(msg.toString());
	}
}