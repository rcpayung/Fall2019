
/**
 * Sorts the incoming elements of data using the Radix Algorithm.
 * <p>
 * @author Riley Payung
 * <p>
 * CS310
 * Spring 2019
 */

import java.util.Scanner;
import java.io.IOException;

public class RadixSort {

	// DO NOT MODIFY INSTANCE VARIABLES PROVIDED BELOW
	// EXCEPT TO ADD JAVADOCS

	// an array of buckets to be used in each round
	/**
	 * The set of buckets to be used in each round, will automatically be flushed
	 * for each round.
	 */
	private SmartArray<SmartArray<Sortable>> buckets;

	// A SmartArray to store values to be sorted.
	// It is also used to store intermediate results after
	// each round and the final group of sorted values.
	// The values should always be sorted in ascending order.
	/**
	 * values to be sorted. The final round will put the sorted order in the values
	 * array.
	 */
	private SmartArray<Sortable> values;

	// ADD MORE PRIVATE MEMBERS HERE IF NEEDED!
	/**
	 * the maximum length of the elements being sorted.
	 */
	private int maxLength = 0;
	/**
	 * the base of the elements being sorted.
	 */
	private int base = 0;
	/**
	 * the current round.
	 */
	private int round = -1;
	
	private int maximumValue = 0;

	/**
	 * Creates a new RadixSort() Object. Initializes values and buckets.
	 */
	// constructor
	public RadixSort() {
		this.buckets = new SmartArray<SmartArray<Sortable>>();
		this.values = new SmartArray<Sortable>();
	}

	/**
	 * Checks to see if the number of rounds matches the length of each of the
	 * elements. Ensures that the array is entirely sorted.
	 * 
	 * O(1)
	 * 
	 * @return true if the elements have been sorted, false if they have not.
	 */
	public boolean isSorted() {
		if (this.round == this.getMaxLength()) {
			return true;
		}
		return false;
	}

	/**
	 * Returns the current round of Radix Sorting
	 * 
	 * O(1)
	 * 
	 * @return return the current round.
	 */
	public int getRound() {
		return this.round;
	}

	/**
	 * Returns the number of buckets that are enabled in the buckets arrays.
	 * 
	 * O(1)
	 * 
	 * @return returns the number of active buckets.
	 */
	public int getNumBuckets() {
		return this.buckets.size();

	}

	/**
	 * Returns the values in the values array.
	 * 
	 * O(1)
	 * 
	 * @return returns the values of the array.
	 * 
	 */
	public SmartArray<Sortable> getValues() {
		return this.values;
	}

	/**
	 * Returns the specified bucket. Automatically checks for an invalid index and
	 * for null pointers.
	 * 
	 * O(1)
	 * 
	 * @return null if the specified bucket does not exist or is not active. Returns
	 *         the bucket at the specified index, otherwise.
	 */
	public SmartArray<Sortable> getBucket(int bucketNum) {
		if (((bucketNum >= base - 1) || bucketNum < 0) && this.buckets.get(bucketNum) == null)
			return null;
		return this.buckets.get(bucketNum);
	}

	/**
	 * Checks each array of values for the longest indices, excluding ones that have
	 * been sanitized. Sets the private variable maxLength in the class.
	 * 
	 * O(N)
	 * 
	 * @return returns the length of the element with the maximum length.
	 * 
	 */
	public int getMaxLength() {
		for (int i = 0; i < this.values.size(); i++) {
			if (this.values.get(i).digits().length() > this.maxLength) {
				this.maxLength = this.values.get(i).digits().length();
			}
		}

		return this.maxLength;
	}

	/**
	 * Initializes the values array from a file, string, etc. Checks for bases, and
	 * initializes accordingly.
	 * 
	 * O(N)
	 * 
	 * @param s - Scanner object
	 * @throws IOException if the input type is invalid.
	 * 
	 */
	public void initValuesFromScanner(Scanner s) throws IOException {
		String type = s.next();
		int base;
		if (!type.equals("a"))
			base = Integer.parseInt(type);
		else
			base = SortableString.BASE;
		int count = 0;
		if (base == SortableString.BASE) {
			this.base = SortableString.BASE;
			while (s.hasNext()) {
				this.values.add(count, new SortableString(s.next()));
				count++;
			}
			round = 0;
		} else {
			this.base = base;
			while (s.hasNext()) {
				this.values.add(count, new SortableNumber(base, s.next()));
				count++;
			}
			round = 0;
		}
		this.maximumValue = base - 1;
		this.buckets = new SmartArray<SmartArray<Sortable>>(this.base);
	}

	/**
	 * Checks for values that do not match the base type. E.G. Binary would not
	 * accept values such as 0210010 due to the fact that binary must either be a 1
	 * or a 0, and hexadecimal would not accept values such as AAHE due to there
	 * being values of only 0-9 and A-F in hexadecimal. The function checks for
	 * values between their respective ranges and the check for bases less than 10
	 * automatically modularizes to fit the respective values.
	 * 
	 * O(N)
	 * 
	 * @return returns the number of sanitized values.
	 */
	public int sanitizeValues() {
		int result = 0;

		for (int i = 0; i < this.values.size(); i++) {
			for (int j = 0; j < this.values.get(i).digits().length(); j++) {
				if (this.base != SortableString.BASE) {
					if (this.base > 9) {
						/* Hexadecimal (Modular, if base 11, will only check for [0-9,A-B]) */
						if (!((this.values.get(i).digits().charAt(j) >= (char) 48
								&& this.values.get(i).digits().charAt(j) <= (char) 57)
								|| (this.values.get(i).digits().charAt(j) >= (char) 65
										&& this.values.get(i).digits().charAt(j) <= (char) (base + 54)))) {
							this.values.delete(i);
							result++;
							i--;
						}
					} else {
						/* Generic Numeric Values */
						if (!(this.values.get(i).digits().charAt(j) >= (char) 48
								&& this.values.get(i).digits().charAt(j) <= ((char) (this.base - 1 + 48)))) {
							this.values.delete(i);
							result++;
							i--;
						}
					}
				} else {
					/* String Values */
					if (!(this.values.get(i).digits().charAt(j) >= (char) 65
							&& this.values.get(i).digits().charAt(j) <= (char) 90
							|| this.values.get(i).digits().charAt(j) == ' ') /* account for space character */) {
						this.values.delete(i);
						result++;
						i--;
					}
				}
			}
		}
		return result;
	}

	/**
	 * Sets each of the elements to be the maximum length of the values input. E.G.
	 * if there were a value that was of length 3, and another of length 6, the
	 * function would automatically pad the digits with 0's and the words with
	 * spaces.
	 * 
	 * O(N)
	 * 
	 * @return returns the number of values whos lengths were changed.
	 * 
	 */
	public int setSameLength() {
		int length = getMaxLength();
		int result = 0;

		for (int i = 0; i < this.values.size(); i++) {
			if (this.values.get(i).digits().length() != length) {
				this.values.get(i).padDigits(length);
				result++;
			}
		}

		return result;
	}

	/**
	 * Goes through one round of sorting with the LSD through radix-style sorting.
	 * Replaces the values with the sorted version. Uses the round number to find
	 * the position of the index/value. Clears the buckets at the beginning of each
	 * round after all values have been sorted in the respective previous rounds.
	 * 
	 * O(N^2)
	 * 
	 */
	public void oneRound() {
		buckets = new SmartArray<SmartArray<Sortable>>(this.base);
		int capacity = this.getValues().capacity();
		for (int i = 0; i < this.getValues().size(); i++) {
			int index = this.getValues().get(i).posToNum(round);

			if (buckets.get(index) != null) {
				buckets.get(index).add(buckets.get(index).size(), values.get(i));
			} else {
				buckets.add(index, new SmartArray<Sortable>());
				buckets.get(index).add(buckets.get(index).size(), values.get(i));
			}
		}
		this.values = new SmartArray<Sortable>(capacity);
		int count = 0;
		for (int i = 0; i < buckets.capacity(); i++) {
			if (buckets.get(i) == null) {
				continue;
			} else {
				for (int j = 0; j < buckets.get(i).size(); j++) {
					this.values.add(count, this.buckets.get(i).get(j));
					count++;
				}
			}
		}

		round++;
	}

	// --------------------------------------------------------
	// example testing code... edit this as much as you want!
	// --------------------------------------------------------
	public static void main(String[] args) {

		// create a RadixSort object and read in from a String
		RadixSort rs = new RadixSort();
		try {
			Scanner s = new Scanner("a BOB TOM AMY TIM");
			rs.initValuesFromScanner(s);
		} catch (IOException e) {
			e.printStackTrace();
			System.exit(0);
		}

		// check features after initialization
		SmartArray<Sortable> vs = rs.getValues();
		if (vs.size() == 4 && vs.get(0).digits().equals("BOB") && vs.get(2).digits().equals("AMY")) {
			System.out.println("Yay 1");
		}
		// get ready to sort
		if (rs.sanitizeValues() == 0 && rs.setSameLength() == 0 && rs.getMaxLength() == 3 && rs.getRound() == 0) {
			System.out.println("Yay 2");
		}

		// one round of radix sort
		rs.oneRound();
		vs = rs.getValues(); // should be "BOB","TOM","TIM","AMY"
		if (!rs.isSorted() && rs.getRound() == 1 && vs.get(0).digits().equals("BOB")
				&& vs.get(2).digits().equals("TIM")) {
			System.out.println("Yay 3");
		}

		// bucket for "M": should contains "TOM" and "TIM" SmartArray<Sortable>
		SmartArray<Sortable> bucket = rs.getBucket(13);
		if (bucket.size() == 2 && bucket.get(0).digits().equals("TOM") && bucket.get(1).digits().equals("TIM")) {
			System.out.println("Yay 4");
		}

		rs.oneRound();
		rs.oneRound();
		if (rs.isSorted()) {
			System.out.println("Yay 5");
			for (int i = 0; i < rs.getValues().size(); i++) {
				System.out.print(rs.getValues().get(i).digits() + " ");
			}
			System.out.println();
		}

		// Note: use provided RadixSortASCII class
		// for debug printing can be helpful

		RadixSort rs2 = new RadixSort();
		try {
			Scanner s = new Scanner("16 3A 12F 301 255 apple 20G");
			rs2.initValuesFromScanner(s);
		} catch (IOException e) {
			e.printStackTrace();
			System.exit(0);
		}

		SmartArray<Sortable> r = rs2.getValues();
		if (rs2.sanitizeValues() == 2 && rs2.setSameLength() == 1 && r.get(0).digits().equals("03A")
				&& rs2.getMaxLength() == 3) {
			System.out.println("Hexadecimal Good");
		}

		rs2.oneRound();
		rs2.oneRound();
		rs2.oneRound();
		if (rs2.isSorted()) {
			System.out.println("Yay 6");
			for (int i = 0; i < rs2.getValues().size(); i++) {
				System.out.print(rs2.getValues().get(i).digits() + " ");
			}
			System.out.println();
		}

		System.out.println();

		RadixSort rs3 = new RadixSort();
		try {
			Scanner s = new Scanner("2 1100 11101 10101 1111 10012");
			rs3.initValuesFromScanner(s);
		} catch (IOException e) {
			e.printStackTrace();
			System.exit(0);
		}

		SmartArray<Sortable> r2 = rs3.getValues();
		if (rs3.sanitizeValues() == 1 && rs3.setSameLength() == 2 && r2.get(0).digits().equals("01100")
				&& rs3.getMaxLength() == 5) {
			System.out.println("Binary Good");
		}

		rs3.oneRound();
		rs3.oneRound();
		rs3.oneRound();
		rs3.oneRound();
		rs3.oneRound();
		if (rs3.isSorted()) {
			System.out.println("Yay 7");
			for (int i = 0; i < rs3.getValues().size(); i++) {
				System.out.print(rs3.getValues().get(i).digits() + " ");
			}
			System.out.println();
		}
	}

}
