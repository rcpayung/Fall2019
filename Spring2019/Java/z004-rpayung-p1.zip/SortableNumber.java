/**
 * Class to ensure the number inserted is a sortable number. Checks are put in
 * place and a minimum length is created to make sure the values are consistent.
 * <p>
 * 
 * @author Riley Payung
 *         <p>
 *         CS310 Spring 2019
 */

public class SortableNumber implements Sortable {

	// ADD PRIVATE MEMBERS HERE IF NEEDED!
	/**
	 * the digits
	 */
	private String digits;
	/**
	 * digits after padding
	 */
	private String paddedDigits;
	/**
	 * base type of the digits
	 */
	private int base;

	/**
	 * Creates a new SortableNumber which implements the interface Sortable.
	 * 
	 * @param base   base of the numeric input (e.g. binary = 2, hex = 16)
	 * @param digits value to input into a sortable number.
	 */
	public SortableNumber(int base, String digits) {
		this.digits = digits;
		this.paddedDigits = digits;
		this.base = base;
	}

	/**
	 * returns the digits of the SortableNumber
	 * 
	 * O(1)
	 * 
	 * @return returns the padded digits if the length of the padded digits is
	 *         longer than that of the digits. returns the digits otherwise.
	 */
	public String digits() {
		if (this.paddedDigits.length() > this.digits.length())
			return this.paddedDigits;
		return this.digits;
	}

	/**
	 * returns the padded digits.
	 * 
	 * O(1)
	 * 
	 * @return returns the padded digits.
	 */
	public String paddedDigits() {
		return this.paddedDigits;
	}

	/**
	 * Returns the maximum value of each individual digit which is the base - 1.
	 * 
	 * O(1)
	 * 
	 * @return returns the base - 1.
	 */
	public int maxNum() {
		// return the max possible numeric value of a single digit as a decimal
		return this.base - 1;
	}

	/**
	 * ensures the index of the string digits is of a proper base, and returns the
	 * value at that spot. Used in determining where values end up in the buckets in
	 * the radix sort.
	 * 
	 * O(N)
	 * 
	 * @param pos - position to check, 0 is the rightmost position (LSD).
	 * @return returns -1 if the index is empty, returns the value otherwise.
	 */
	public int posToNum(int pos) {
		// return the value at location pos of the padded digits as a decimal
		// rightmost position (least significant digit position) is 0
		// return -1 if position is invalid or any exception occurs

		String index = "";
		int count = 0;
		char[] arr = paddedDigits.toCharArray();

		for (int i = arr.length - 1; i >= 0; i--) {
			if (count == pos) {
				index += arr[i];
				break;
			}
			count++;
		}
		if (index == "")
			return -1;
		return Integer.parseInt(index, base);
	}

	/**
	 * pads the digits if the length of the element is not long enough. pads numbers
	 * with 0's in the front.
	 * 
	 * O(N)
	 * 
	 * @param minLength the minimum length that the element should be.
	 */
	public void padDigits(int minLength) {
		// pad to ensure the length of padded string is
		// at least minLength
		if (digits().length() == minLength)
			return;
		else {
			String str = new String();
			for (int i = 0; i < minLength - digits().length(); i++)
				str += "0";
			str += this.digits();
			this.paddedDigits = str;
		}
	}

	// --------------------------------------------------------
	// example testing code... edit this as much as you want!
	// --------------------------------------------------------

	public static void main(String[] args) {

		// create a decimal
		SortableNumber num = new SortableNumber(10, "123");
		// check features
		if ((num.maxNum() == 9) && (num.digits().equals("123")) && (num.posToNum(0) == 3)) {
			System.out.println("Yay 1");
		}

		// pad
		num.padDigits(5);
		if (num.paddedDigits().length() == 5 && num.posToNum(2) == 1 && num.posToNum(4) == 0) {
			System.out.println("Yay 2");
		}

		// create a hex
		SortableNumber hex = new SortableNumber(16, "AB");

		// check features
		if (hex.maxNum() == 15 && hex.posToNum(0) == 11 && hex.posToNum(1) == 10 && hex.posToNum(10) == -1) {
			System.out.println("Yay 3");
		}

	}
}