#include "stdafx.h"
#include "Game.h"
#include <iostream>
#include "Sprite.h"
#include "Texture.h"
#include "Vec2F.h"
#include "TileMap.h"
#include "Player.h"
#include "HUD.h"
using namespace std;

Player* player;
bool isDead = false;
SDL_Renderer * Game::renderer = nullptr;
Sprite* enemy;
TileMap* map;
HUD* hud;

Game::Game() {

}


Game::~Game() {

}

void Game::init(const char* title, int posX, int posY, int width, int height, bool fs) {
	int flags = 0;
	if (SDL_Init(SDL_INIT_VIDEO) != 0) {
		cout << "Video subsystem could not be initialized." << endl;
		return;
	}
	if (fs) {
		flags = SDL_WINDOW_FULLSCREEN;
	}

	window = SDL_CreateWindow(title, posX, posY, width, height, flags);
	if (window == NULL) {
		return;
	}
	renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_PRESENTVSYNC);
	if (renderer == NULL) {
		return;
	}

	running = true;
	player = new Player("SummerSalt",Vec2F(250,250));
	map = new TileMap();
	hud = new HUD();
	enemy = new Sprite("Assets/player.jpg", Vec2F(64, 64), Vec2F());
}


void Game::handleEvents() {
	SDL_Event event;
	SDL_PollEvent(&event);
	switch (event.type) {
	case SDL_QUIT:
		running = false;
		break;
	case SDL_KEYDOWN:
		switch (event.key.keysym.sym) {
		case SDLK_ESCAPE:
			running = false;
			break;
		case SDLK_w:
			player->moveUpDown(-1);
			break;
		case SDLK_s:
			player->moveUpDown(1);
			break;
		case SDLK_a:
			player->moveLeftRight(-1);
			break;
		case SDLK_d:
			player->moveLeftRight(1);
			break;
		default:
			break;
		}
		break;
	case SDL_KEYUP:
		switch (event.key.keysym.sym) {

		case SDLK_w:

				player->moveUpDown(0);
			break;
		case SDLK_s:
				player->moveUpDown(0);
			break;
		case SDLK_a:
				player->moveLeftRight(0);
			break;
		case SDLK_d:
				player->moveLeftRight(0);
			break;
		case SDLK_r:
			player->decreaseMana(100);
		default:
			break;
		}
		break;
	case SDL_MOUSEMOTION:
		break;
	case SDL_MOUSEBUTTONDOWN:
		if (event.button.x < 100 && event.button.x > 0 && event.button.y < 100 && event.button.y > 0 && player->getCurMP() > 50) {
			player->decreaseHealth(150);
			player->decreaseMana(50);
		}
		break;
	default:
		break;
	}
}


void Game::update() {
	player->update();
	// Get HUD information:
	hud->getPlayerHP(player->getCurHP(), player->getMaxHP());
	hud->getPlayerMP(player->getCurMP(), player->getMaxMP());
	// Update the HUD:
	hud->update(player->getPosition());

	player->update();
	if (player->getCurHP() <= 0) {
		running = false;
	}

	enemy->update();
}

bool rendered = false;

void Game::render() {
	SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);
	SDL_RenderClear(renderer);
	map->render();
	player->render();
	enemy->render();
	hud->render();
	SDL_RenderPresent(renderer);
}

void Game::clean() {
	hud->clean();
	SDL_DestroyWindow(window);
	SDL_DestroyRenderer(renderer);
	SDL_Quit();
}