#include "stdafx.h"
#include "Player.h"
#include <iostream>
#include <vector>

SDL_Texture* player;
std::vector<SDL_Texture*> textures;
int ctr;

Player::Player(const char* name, Vec2F pos) {
	textures.push_back(Texture::loadTexture("Assets/playerRast.png"));
	textures.push_back(Texture::loadTexture("Assets/playerMoveDown.png"));
	textures.push_back(Texture::loadTexture("Assets/playerMoveUp.png"));
	player = textures[0];
	this->name = name;
	this->position = pos;
	this->maxHP = HP = 500;
	this->maxMP = MP = 250;
	dest.w = src.w = 64;
	dest.h = src.h = 64;

	std::cout << "Player Initialized" << std::endl;

	ctr = 0;
}


Player::~Player()
{
}

void Player::update() {
	ctr++;

	position.x += moveS;
	position.y += moveUD;

	dest.x = position.x;
	dest.y = position.y;

	// Increase player health by small amount every 4 ticks
	if (ctr % 4 == 0) {
		increaseHealth(1);

	}
	// increase player mana by small amount ever 25 ticks
	if (ctr % 10 == 0) {
		increaseMana(1);
	}

}

void Player::render() {
	Texture::Draw(player, src, dest);
}

void Player::increaseVelocity(float amount) {
	this->velocity = amount;
}

void Player::moveLeftRight(int speed) {
	this->moveS = (int) speed * velocity;
}
void Player::moveUpDown(int speed) {
	if (speed > 0) player = textures[1];
	else if (speed < 0) player = textures[2];
	else player = textures[0];
	this->moveUD = (int) speed * velocity;
}

void Player::decreaseHealth(int amount) {
	if (HP > 0)
		if (HP - amount < 0) {
			HP = 0;
		} else 
			this->HP -= amount;
}

void Player::decreaseMana(int amount) {
	if (MP > 0)
		if (MP - amount < 0) {
			return;
		} else
			this->MP -= amount;
}


void Player::increaseHealth(int amount) {
	if (this->HP == 0) return;
	if (this->HP < maxHP) {
		HP += amount;
	}
}
void Player::increaseMana(int amount) {
	if (this->MP < maxMP) {
		MP += amount;
	}
}