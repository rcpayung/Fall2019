#pragma once
#include <string>

class Vec2F
{
public:
	int x = 0, y = 0;
	Vec2F();
	Vec2F(int a);
	Vec2F(int x, int y);
	~Vec2F();
	Vec2F operator +=(Vec2F);
	Vec2F operator -=(Vec2F);
	std::string toString() {
		std::string re;
		re.append("(");
		re.append(std::to_string(x/64));
		re.append(",");
		re.append(std::to_string(y/64));
		re.append(")");

		return re;
	}
};

