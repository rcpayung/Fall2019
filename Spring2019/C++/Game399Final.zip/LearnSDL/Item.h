#pragma once
#include "Game.h"
#include "Texture.h"
#include "Vec2F.h"
class Item {
private:
	SDL_Texture*	itemTexture;
	int				atkDamage;
	Vec2F			position;
public:
	Item(int itemID); // Non weapon
	Item(int itemID, int atkDamage); // Weapon
	const int getAtkDamage() { return this->atkDamage; }
	~Item();
	void update();
	void render();

};

