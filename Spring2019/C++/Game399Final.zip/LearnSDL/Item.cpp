#include "stdafx.h"
#include "Item.h"
#include <vector>

std::vector<const char*> iList = {"Assets/item/00.png","Assets/item/01.png","Assets/item/02.png","Assets/item/03.png"};

Item::Item(int itemID) {
	itemTexture = Texture::loadTexture(iList[itemID]);
	atkDamage = 0;
}

Item::Item(int itemID, int atkDamage) {
	itemTexture = Texture::loadTexture(iList[itemID]);
	this->atkDamage = atkDamage;
}

Item::~Item() {

}
