#include "stdafx.h"
#include "Vec2F.h"

Vec2F::Vec2F() {
	this->x = 0;
	this->y = 0;
}

Vec2F::Vec2F(int a) {
	this->x = a;
	this->y = a;
}

Vec2F::Vec2F(int x, int y) {
	this->y = y;
	this->x = x;
}

Vec2F Vec2F::operator +=(Vec2F another) {
	this->x += another.x;
	this->y += another.y;

	return *this;
}

Vec2F Vec2F::operator -=(Vec2F another) {
	this->x -= another.x;
	this->y -= another.y;

	return *this;
}

Vec2F::~Vec2F()
{
}
