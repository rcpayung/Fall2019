#include "stdafx.h"
#include "Texture.h"
#include "SDL_image.h"
#include <iostream>

SDL_Texture* Texture::loadTexture(const char* file) {
	SDL_Surface* temp = IMG_Load(file);
	SDL_Texture* tex = SDL_CreateTextureFromSurface(Game::renderer, temp);
	SDL_FreeSurface(temp);
	if (tex == NULL) {
		std::cout << "NULL TEXTURE" << std::endl;
	}
	return tex;
}

void Texture::Draw(SDL_Texture* tex, SDL_Rect src, SDL_Rect dest) {
	SDL_RenderCopy(Game::renderer, tex, &src, &dest);
}