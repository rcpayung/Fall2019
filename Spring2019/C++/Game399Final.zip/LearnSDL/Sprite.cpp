#include "stdafx.h"
#include "Sprite.h"
#include "Texture.h"
#include <iostream>

int counter = 0;
bool increasing = false;
int countNum = 0;

Sprite::Sprite(const char* fileName, Vec2F size, Vec2F position) {
	ObjectTexture = Texture::loadTexture(fileName);
	if (ObjectTexture == NULL) {
		std::cout << "Texture not loaded" << std::endl;
	}
	this->size = size;
	this->position = position;

}

Sprite::Sprite(const char* fileName, Vec2F size) {
	ObjectTexture = Texture::loadTexture(fileName);
	this->size = size;
	this->position = Vec2F(0,0);

}

Sprite::~Sprite() {}

void Sprite::update() {
	drect.w = size.x;
	drect.h = size.y;
	drect.x = position.x;
	drect.y = position.y;
}


void Sprite::render() {
	SDL_RenderCopy(Game::renderer, ObjectTexture, NULL, &drect);
}


void Sprite::clean() {
	SDL_DestroyTexture(ObjectTexture);
}

Vec2F Sprite::getPos() {
	return this->position;
}

Vec2F Sprite::getSize() {
	return this->size;
}