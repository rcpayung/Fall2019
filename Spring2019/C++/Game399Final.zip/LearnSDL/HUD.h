#pragma once
#include "Texture.h"
#include "Game.h"
#include "SDL.h"
#include "Vec2F.h"

class HUD {
private:
	SDL_Rect src, dest;
	float currentHP, maxHP, currentMP, maxMP;
public:
	HUD();
	~HUD();
	void getPlayerHP(int current, int max);
	void getPlayerMP(int current, int max);
	int modulateHP();
	int modulateMP();
	void update(Vec2F position);
	void render();
	void clean();
};

