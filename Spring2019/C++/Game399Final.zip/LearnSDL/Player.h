#pragma once
#include "Vec2F.h"
#include "Game.h"
#include "Texture.h"
#include <vector>

class Player {
private:
	SDL_Texture*					playerTexture;
	const char*						name;
	int								HP, maxHP, MP, maxMP, attackDamage;
	Vec2F							position;
	SDL_Rect						src, dest;
	std::vector<int>				items;
	int								moveS, moveUD;
	float							velocity = 3.0f;
public:
	Player(const char* name, Vec2F pos);
	~Player();
	void update();
	void render();

	void increaseVelocity(float amount);
	void moveLeftRight(int speed);
	void moveUpDown(int speed);
	void decreaseHealth(int amount);
	void decreaseMana(int amount);
	void increaseHealth(int amount);
	void increaseMana(int amount);

	Vec2F getPosition()  { return this->position; }
	const int getMaxHP() { return this->maxHP;	  }
	const int getMaxMP() { return this->maxMP;	  }
	const int getCurHP() { return this->HP;		  }
	const int getCurMP() { return this->MP;		  }
};

