#include "stdafx.h"
#include "HUD.h"
#include <iostream>
#include <string>


SDL_Texture* texture;
SDL_Rect healthBar;
SDL_Rect manaBar;
SDL_Rect healthInfo;

HUD::HUD() {
	texture = Texture::loadTexture("Assets/GameUI.png");

	src.w = 300;
	src.h = 600;
	src.x = 0;
	src.y = 0;
	std::cout << "Initialized HUD" << std::endl;
}

HUD::~HUD()
{
}

void HUD::update(Vec2F position) {
	src.w = dest.w = 200;
	src.h = dest.h = 600;
	dest.x = 600;
	dest.y = 0;

	healthBar.h = 12; // 15px;
	healthBar.w = modulateHP();
	healthBar.x = 250 + 363;
	healthBar.y = 250 - 75;

	manaBar.h = 12; // 15px;
	manaBar.w = modulateMP();
	manaBar.x = 250 + 363; // 
	manaBar.y = 250 - 55;
}

void renderElements() {
	SDL_SetRenderDrawColor(Game::renderer, 225, 140, 140, 255);
	SDL_RenderFillRect(Game::renderer, &healthBar);
	SDL_SetRenderDrawColor(Game::renderer, 140, 140, 225, 255);
	SDL_RenderFillRect(Game::renderer, &manaBar);
}

void HUD::render() {
	SDL_RenderCopy(Game::renderer, texture, NULL, &dest);
	renderElements();
}


void HUD::clean() {
	SDL_DestroyTexture(texture);
}

void HUD::getPlayerHP(int current, int max) {
	this->currentHP = (float) current;
	this->maxHP = (float) max;
}
void HUD::getPlayerMP(int current, int max) {
	this->currentMP = (float) current;
	this->maxMP = (float) max;
}
int HUD::modulateHP() {
	float modulatedNumeric;
	modulatedNumeric = ((currentHP / maxHP) * 176);
	//USED FOR TESTING: std::cout << "(" << currentHP << "," << maxHP << "," << std::to_string(modulatedNumeric) << "," << (this->currentHP / this->maxHP) << ")" << std::endl;
	return (int) modulatedNumeric;
}

int HUD::modulateMP() {
	float modulatedInteger = 0;

	modulatedInteger = ((currentMP / maxMP) * 176);

	return (int) modulatedInteger;
}