#pragma once
#include "Game.h"

class TileMap {
private:
	int tileMap[10][10];
public:
	TileMap(); 
	TileMap(int room[10][10]);
	~TileMap() {};
	void render();
};

