#pragma once
#include "SDL.h"
#include "SDL_image.h"
#include "Vec2F.h"
#include "Game.h"
class Sprite{
private:
	SDL_Texture* ObjectTexture;
	SDL_Rect drect;
	Vec2F size;
public:
	Vec2F position;
	int health = 10;
	Sprite(const char* fileName, Vec2F size, Vec2F position);
	Sprite(const char* fileName, Vec2F size);
	~Sprite();
	void update();
	void render();
	void clean();
	Vec2F getPos();
	Vec2F getSize();
};

