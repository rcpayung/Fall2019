#include "stdafx.h"
#include "TileMap.h"
#include "Texture.h"
#include <vector>
#include <iostream>

const int TILESIZE = 64;

SDL_Texture* grass;

SDL_Rect src, dest;

// Default Map:
const int DefaultMap[10][10] = {
	{ 0,0,0,0,0,0,0,0,0,0 },
	{ 0,0,0,0,0,0,0,0,0,0 },
	{ 0,0,0,0,0,0,0,0,0,0 },
	{ 0,0,0,0,0,0,0,0,0,0 },
	{ 0,0,0,0,0,0,0,0,0,0 },
	{ 0,0,0,0,0,0,0,0,0,0 },
	{ 0,0,0,0,0,0,0,0,0,0 },
	{ 0,0,0,0,0,0,0,0,0,0 },
	{ 0,0,0,0,0,0,0,0,0,0 },
	{ 0,0,0,0,0,0,0,0,0,0 }
};

TileMap::TileMap() {
	grass = Texture::loadTexture("Assets/01.png");
	for (int row = 0; row < 10; row++) {
		for (unsigned int col = 0; col < 10; col++) {
			tileMap[row][col] = DefaultMap[row][col];
		}
	}

	src.h = TILESIZE; 
	src.w = TILESIZE;
}

TileMap::TileMap(int room[10][10]) {
	for (int row = 0; row < 10; row++) {
		for (unsigned int col = 0; col < 10; col++) {
			tileMap[row][col] = room[row][col];
		}
	}
}

void TileMap::render() {
	for (int row = 0; row < 10; row++) {
		for (unsigned int col = 0; col < 10; col++) {
			dest.x = col * TILESIZE;
			dest.y = row * TILESIZE;
			dest.w = TILESIZE;
			dest.h = TILESIZE;
			
			switch (tileMap[row][col]) {
			case 0:
				Texture::Draw(grass, src, dest);
				break;
			default:
				break;
			}
		}
	}
}



