#include "stdafx.h"
#include "Inventory.h"

Inventory::~Inventory()
{
}

Inventory::Inventory() {
	this->items.push_back(Item()); // create a placeholder item.
}

// Checks for an empty slot in the inventory

bool Inventory::checkForEmptySlot(Item item) {
	for (unsigned int i = 0; i < this->items.size(); i++) {
		if (this->items[i].getType() == -1) {
			return true;
		}
	}
	return false;
}

// adds an item to the inventory

void Inventory::addItem(Item item) {
	// Check for a placeholder item first:
	bool emptySlot = checkForEmptySlot(item);

	if (this->items.size() >= this->MAX_ITEMS && !emptySlot) {
		return;
	}
	else {
		for (unsigned int i = 0; i < this->items.size(); i++) {
			if (this->items[i].getType() == -1) {
				this->items[i] = item;
				return;
			}
		}
	}
	this->items.push_back(item);
}

// removes an item by replacing it with a placeholder

void Inventory::removeItem(Item item) {
	for (unsigned int i = 0; i < this->items.size(); i++) {
		if (this->items[i].getName() == item.getName()) {
			if (items[i].getAmount() > 1) {
				items[i].decreaseAmount();
				return;
			}
			items.erase(items.begin() + i);
			return;
		}
	}
}

// removes an item by replacing it with a placeholder

void Inventory::removeItem(unsigned int index) {
	if (index > this->items.size())
		return;
	for (unsigned int i = 0; i < this->items.size(); i++) {
		if (i == index) {
			items.erase(items.begin() + i); // Set as default item ("", -1)
			return;
		}
	}
}

// replaces the given item with another given item

void Inventory::replace(Item replaceThis, Item replaceWith) {
	for (unsigned int i = 0; i < this->items.size(); i++) {
		if (this->items[i].getName() == replaceThis.getName()) {
			this->items[i] = replaceWith; // Set as default item ("", -1)
			break;
		}
	}
}

void Inventory::useItem(Item item) {
	for (unsigned int i = 0; i < this->items.size(); i++) {
		if (this->items[i].getName() == item.getName()) {
			removeItem(item);
			cout << "Used: " << item.getName() << endl;
			break;
		}
	}
}


void Inventory::useItem(std::string name) {
	for (unsigned int i = 0; i < items.size(); i++) {
		if (items[i].getName() == name) {
			if (items[i].getAmount() > 1) {
				items[i].decreaseAmount();
			}
			else {
				items.erase(items.begin() + i);
			}
		}
	}
}
bool Inventory::hasItem(std::string name) {
	for (unsigned int i = 0; i < items.size(); i++) {
		if (items[i].getName() == name) {
			return true;
		}
	}
	return false;
}

Item Inventory::getItem(std::string itemName) {
	for (unsigned int i = 0; i < this->items.size(); i++) {
		if (this->items[i].getName() == itemName) {
			return this->items[i];
		}
	}
	return Item();
}

int Inventory::numOfItems() {
	return items.size() - 1;
}

std::string Inventory::toString() {
	std::string result = "{";
	for (unsigned int i = 1; i < items.size(); i++) {		
		result.append(items[i].toString());
		if (i != items.size() - 1) {
			result.append(", ");
		}
	}
	result.append("}");
	return result;
}