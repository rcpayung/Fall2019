#include "stdafx.h"
#include "Mob.h"

// Constructors:

Mob::Mob(const int UNIQUE_ID, std::string name,int HP, int damage) {
	this->name = name;
	this->maxHP = HP;
	this->hp = HP;
	this->maxDamage = damage;
	this->id = UNIQUE_ID;
}

Mob::Mob() {
	this->name = "";
	this->hp = 0;
	this->maxDamage = 0;
	this->id = -1;
}

Mob::~Mob() {

}

// Setters:

void Mob::setID(int id) {
	this->id = id;
}

void Mob::setMaxHP(int amount) {
	this->maxHP = amount;
}
void Mob::setHP(int amount) {
	this->hp = amount;
}
void Mob::setMaxDamage(int amount) {
	this->maxDamage = amount;
}

void Mob::damageMob(int amount, bool isWeakness) {
	double multiplier = 1.5;
	int totalDamage = 0;

	if (isWeakness) {
		this->setHP((int)(this->hp - (amount * multiplier)));
		totalDamage = (int) (amount * multiplier);
	}
	else {
		this->setHP((int) (this->hp - amount));
		totalDamage = amount;
	}
	cout << "Dealt " << totalDamage << " damage to " << this->getName() << endl;
}

// Getters:

int Mob::getID() {
	return this->id;
}

std::string Mob::getName() {
	return this->name;
}

int Mob::getMaxHP() {
	return this->maxHP;
}
int Mob::getHP() {
	return this->hp;
}

int Mob::getMaxDamage() {
	return this->maxDamage;
}

string Mob::getWeakness() {
	if (this->getName()._Equal("Dragon"))
		return "Magic Bolt";
	return "";
}

// Functions:
bool Mob::equals(Mob mob) {
	if (this->getName() == mob.getName())
		return true;
	return false;
}

// Parsing:

std::string Mob::toString() {
	std::string result;
	result.append(this->getName() + " {");
	result.append("HP: "+ std::to_string(this->getHP()));
	result.append("/" + to_string(this->getMaxHP()));
	result.append(", Max Damage: " + std::to_string(this->getMaxDamage()));
	result.append("}");
	
	return result;
}