#pragma once
#include <string>
#include <vector>

using namespace std;

class Command {
public:
	Command(string, string);
	Command();
	virtual ~Command();

	bool isValidCommand(string);
	string getCommands();
	string getCommand();
	string getParameter();
	bool parseCommand(string);
private:
	vector<string> VALID_COMMANDS =					{ "exit","enter","flee","pickup","use","equip","attack" };
	vector<string> UPPER_COMMANDS =					{ "EXIT","ENTER","FLEE","PICKUP","USE","EQUIP","ATTACK" };
	vector<string> FIRST_LETTER_UPPER_COMMANDS =	{ "Exit","Enter","Flee","Pickup","Use","Equip","Attack" };
	string command;
	string parameter;
};