#include "stdafx.h"
#include <iostream>
#include "Command.h"

Command::Command(string command, string parameter) {
	this->command = command;
	this->parameter = parameter;
}
Command::Command() {

}

Command::~Command() {

}

bool Command::isValidCommand(string command) {
	if (command == "exit" || command == "Exit" || command == "EXIT" || command == "flee" || command == "Flee" || command == "FLEE") {
		return true;
	}
	
	for (unsigned int i = 0; i < this->VALID_COMMANDS.size(); i++) {
		if (command == VALID_COMMANDS[i] || command == UPPER_COMMANDS[i] || command == FIRST_LETTER_UPPER_COMMANDS[i]) {
			return true;
		}
	}
	return false;
}

string Command::getCommands() {
	string result = "Valid Commands: ";

	for (unsigned int i = 0; i < VALID_COMMANDS.size(); i++) {
		result.append(VALID_COMMANDS[i]);
		if (i < VALID_COMMANDS.size() - 1) {
			result.append(", ");
		}
	}
	return result;
}

string Command::getCommand() {
	return this->command;
}

string Command::getParameter() {
	return this->parameter;
}

bool Command::parseCommand(string input) {
	if (input == "exit" || input == "Exit" || input == "EXIT" || input == "flee" || input == "Flee" || input == "FLEE") {
		this->command = input;
		return true;
	}
	if (input.empty()) {
		return false;
	}
	else {
		bool commandFound = false;
		for (unsigned int i = 0; i < input.length(); i++) {
			if (input[i] == ' ' && !commandFound) {
				this->command = input.substr(0, i);
				commandFound = true;
			}
			if (commandFound) {
				if (command == "exit" || command == "Exit" || command == "EXIT" || command == "flee" || command == "Flee" || command == "FLEE") {
					break;
				}
				this->parameter = input.substr(i+1, input.length());
				break;
			}
			
		}
		bool isValid = isValidCommand(command);

		if (isValid && (command == "exit" || command == "Exit" || command == "EXIT" || command == "flee" || command == "Flee" || command == "FLEE")) {
			return true;
		}

		if (isValid && parameter != "") {
			return true;
		}
		else {
			return false;
		}
	}
}

