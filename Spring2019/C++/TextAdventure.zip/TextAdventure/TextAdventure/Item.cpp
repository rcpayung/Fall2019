#include "stdafx.h"
#include "Item.h"

int Item::totalItems = 0;

Item::Item(std::string itemName, bool stackable, int amount) {
	this->itemName = itemName;
	this->stackable = stackable;
	if (stackable) {
		this->amount = amount;
	}
	else {
		this->amount = 0;
	}
	this->itemID = totalItems;
	totalItems++;
}

Item::Item() {

}


Item::~Item() {

}


std::string Item::getName() {
	return itemName;
}

int Item::getType() {
	return itemType;
}

bool Item::getStackable() {
	return stackable;
}

int Item::getID() {
	return itemID;
}

int Item::getAmount() {
	return amount;
}

bool Item::equals(Item item) {
	if (this->getName() == item.getName()) {
		return true;
	}
	return false;
}


void Item::increaseAmount() {
	if (stackable) {
		amount++;
		return;
	}
	else {
		std::cout << "Item cannot be stacked." << std::endl;
	}
}

void Item::decreaseAmount() {
	if (this->amount > 1) {
		amount--;
		return;
	}
	else {
		std::cout << "Cannot Decrease. Unknown bug. Please see debug tracing." << std::endl;
	}
}

std::string Item::toString() {
	return getName() + " x" + std::to_string(getAmount());
}

 std::string Consumable::toString() {
	if (itemName == "Mana Potion")
		return "Consumable: {" + getName() + ", Regenerates: " + std::to_string(getBuffAmount()) + " Mana}";
	else
		return "Consumable: {" + getName() + ", Heals: " + std::to_string(getBuffAmount()) + " Health}";
}

std::string Weapon::toString() {
	if (getDefendable()) {
		return "Weapon: {" + getName() + ", Damage: " + std::to_string(getDamage()) + ", Defense: " + std::to_string(getDefense()) + "}";
	}
	else {
		return "Weapon: {" + getName() + ", Damage: " + std::to_string(getDamage()) + "}";
	}

	
}

// Consumable Child Class:

Consumable::Consumable(int amount, bool stackable, std::string itemName, int buffAmount) {
	this->itemName = itemName;
	this->itemType = 1;
	this->buffAmount = buffAmount;
	
	this->stackable = stackable;
	if (stackable) {
		this->amount = amount;
	}
	else {
		this->amount = 0;
	}
	this->itemID = totalItems;
	totalItems++;
}
Consumable::Consumable() {
	
}
Consumable::~Consumable() {

}

int Consumable::getBuffAmount() {
	return buffAmount;
}

// Weapon Child Class:

Weapon::Weapon(std::string itemName, int maxDamage, bool isDefendable, int defense) {
	this->amount = 1;
	this->stackable = false;
	this->itemName = itemName;
	this->itemType = 2;
	this->damage = damage;
	this->isDefendable = isDefendable;
	if (this->isDefendable) {
		this->defense = defense;
	}
	else {
		this->defense = 0;
	}
	this->itemID = totalItems; // sets the unique id of this item
	totalItems++; // Increases the static number of items.
}

Weapon::Weapon() {

}

Weapon::~Weapon() {

}

int Weapon::getDamage() {
	return damage;
}

int Weapon::getDefense() {
	return defense;
}

bool Weapon::getDefendable() {
	return isDefendable;
}