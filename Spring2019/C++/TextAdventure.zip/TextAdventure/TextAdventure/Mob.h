#pragma once
#include <string>
#include <vector>
#include <iostream>

using namespace std;

class Mob {
public:
	Mob(const int UNIQUE_ID, string name, int maxHP, int maxDMG);
	Mob();
	virtual ~Mob();
	
	// Setters:

	void setID(int id);
	void setMaxHP(int amount);
	void setHP(int amount);
	void setMaxDamage(int amount);
	void damageMob(int amount, bool isWeakness);

	//Getters: 

	int getID();
	string getName();
	int getMaxHP();
	int getHP();
	int getMaxDamage();
	string getWeakness();

	// Functions:

	bool equals(Mob mob);

	// Parsing:

	string toString();

private:
	int id;
	string name;
	int maxHP = 0;
	int hp = 0;
	int maxDamage = 0;
	enum Weakness {
		MAGIC_BOLT,SWORD,
	};
};

