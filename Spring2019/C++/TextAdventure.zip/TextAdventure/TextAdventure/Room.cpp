#include "stdafx.h"
#include "Room.h"

using namespace std;

//	void Room::removeMob(Mob mob) {
//		mobs.erase(mobs.begin() + indexOf(mob));
//		numOfMobs--;
//	}


Room::Room() {

}

Room::Room(int roomID, std::string roomName, std::string roomDescription, std::vector<Room> exits, std::vector<Mob> mobs, std::vector<Item> items) {
	this->roomID = roomID;
	this->roomName = roomName;
	this->roomDescription = roomDescription;
	this->exits = exits;
	this->mobs = mobs;
	this->items = items;
}

Room::Room(int roomID, std::string roomName, std::string roomDescription) {
	this->roomID = roomID;
	this->roomName = roomName;
	this->roomDescription = roomDescription;
}

Room::~Room() {

}


// Add data to this Room:
void Room::addExit(Room room) {
	// Check if the room already exists in the exits:
	for (unsigned int i = 0; i < exits.size(); i++) {
		if (exits[i].equals(room)) {
			return;
		}
	}
	// Check for empty values:
	for (unsigned int i = 0; i < exits.size(); i++) {
		if (exits[i].equals(Room())) {
			exits[i] = room;
			numberOfExits++;
			return;
		}
	}
	// If both are true, return if not, add it to the end of the vector:
	exits.push_back(room);
	numberOfExits++;
}
// Mob
void Room::addMob(Mob mob) {
	// Can have multiple of the same enemy type.
	mobs.push_back(mob);
	numberOfMobs++;
	// FOR TESTING PURPOSES: cout << to_string(numberOfMobs) << endl;
}
// Item
void Room::addItem(Item item) {
	items.push_back(item);
	numberOfItems++;
}


// Remove data from this Room:
// Exit
void Room::removeExit(Room room) {
	if (room.equals(Room())) {
		return;
	}
	else {
		for (unsigned int i = 0; i < exits.size(); i++) {
			if (exits[i].equals(room)) {
				exits.erase(exits.begin() + indexOf(exits[i]));
				numberOfExits--;
				return;
			}
		}
	}
	cout << "Unable to remove exit: room not found." << endl;
}
void Room::removeExit(std::string exitName) {
	if (getExit(exitName).equals(Room())) {
		return;
	}
	else {
		for (unsigned int i = 0; i < exits.size(); i++) {
			if (exits[i].getName() == exitName) {
				exits.erase(exits.begin() + indexOf(exits[i]));
				numberOfExits--;
				return;
			}
		}
	}
	cout << "Unable to remove exit: room not found." << endl;
}
// Mob
void Room::removeMob(Mob mob) {
	if (mob.equals(Mob())) {
		return;
	}
	else {
		for (unsigned int i = 0; i < mobs.size(); i++) {
			if (mobs[i].equals(mob)) {
				mobs.erase(mobs.begin() + indexOf(mobs[i]));
				numberOfMobs--;
				return;
			}
		}
	}
	cout << "Unable to remove mob: mob not found." << endl;
}
void Room::removeMob(std::string mobName) {
	if (getMob(mobName)->equals(Mob())) {
		return;
	}
	else {
		for (unsigned int i = 0; i < mobs.size(); i++) {
			if (mobs[i].getName() == mobName) {
				mobs.erase(mobs.begin() + indexOf(mobs[i]));
				numberOfMobs--;
				return;
			}
		}
	}
	cout << "Unable to remove mob: mob not found." << endl;
}
// Item
void Room::removeItem(Item item) {
	if (item.equals(Item())) {
		return;
	}
	else {
		for (unsigned int i = 0; i < items.size(); i++) {
			if (items[i].equals(item)) {
				items.erase(items.begin() + indexOf(items[i]));
				numberOfItems--;
				return;
			}
		}
	}
	cout << "Unable to remove item: item not found." << endl;
}
void Room::removeItem(std::string itemName) {
	if (getItem(itemName).equals(Item())) {
		return;
	}
	else {
		for (unsigned int i = 0; i < items.size(); i++) {
			if (items[i].getName() == itemName) {
				items.erase(items.begin() + indexOf(items[i]));
				numberOfItems--;
				return;
			}
		}
	}
	cout << "Unable to remove item: item not found." << endl;
}


int Room::indexOf(Mob mob) {
	for (unsigned int i = 0; i < mobs.size(); i++) {
		if (mobs[i].getName() == mob.getName()) {
			return i;
		}
	}
	return -1;
}
int Room::indexOf(Item item) {
	for (unsigned int i = 0; i < items.size(); i++) {
		if (items[i].getName() == item.getName()) {
			return i;
		}
	}
	return -1;
}
int Room::indexOf(Room exit) {
	for (unsigned int i = 0; i < exits.size(); i++) {
		if (exits[i].getName() == exit.getName()) {
			return i;
		}
	}
	return -1;
}


// Get data from this Room:
// Item
Item Room::getItem(std::string name) {
	for (unsigned int i = 0; i < items.size(); i++) {
		if (items[i].getName() == name) {
			return items[i];
		}
	}
	return Item();
}

std::vector<Item> Room::getItems() {
	return items;
}

//Mob
Mob * Room::getMob(std::string name) {
	for (unsigned int i = 0; i < mobs.size(); i++) {
		if (mobs[i].getName() == name) {
			return &mobs[i];
		}
	}
	return nullptr;
}
std::vector<Mob> * Room::getMobs() {
	return &mobs;
}

//Exit
Room Room::getExit(std::string name) {
	for (unsigned int i = 0; i < exits.size(); i++) {
		if (exits[i].getName() == name) {
			return exits[i];
		}
	}
	return Room();
}
std::vector<Room> Room::getExits() {
	return exits;
}

//Room data:
int Room::getId() {
	return this->roomID;
}

std::string Room::getName() {
	return this->roomName;
}

std::string Room::getDescription() {
	return this->roomDescription;
}

int Room::getNumberOfExits() {
	return this->numberOfExits;
}
int Room::getNumberOfMobs() {
	return this->numberOfMobs;
}
int Room::getNumberOfItems() {
	return this->numberOfItems;
}




bool Room::equals(Room room) {
	return (this->getName() == room.getName());
}

string Room::toString() {
	string result;
	result.append("Location: " + getName() + "\n");
	result.append( getDescription() + "\n\nMobs: [");
	for (unsigned int i = 0; i < mobs.size(); i++) {
		result.append( mobs[i].toString());
		if (i <  mobs.size() - 1) {
			result.append(", ");
		}
	}
	if (mobs.empty()) {
		result.append("No Mobs");
	}
	result.append("]");
	result.append("\nItems: [");
	for (unsigned int i = 0; i < items.size(); i++) {
		result.append(items[i].toString());
		if (i < items.size() - 1) {
			result.append(", ");
		}
	}
	if (items.empty()) {
		result.append("No Items");
	}
	result.append("]");
	result.append("\nExits: [");
	for (unsigned int i = 0; i < exits.size(); i++) {
		result.append(to_string(i) + ": " + exits[i].getName());
		if (i < exits.size() - 1) {
			result.append(", ");
		}
	}
	if (exits.empty()) {
		result.append("No Exits. You're stuck here.");
	}
	result.append("]");

	return result;
}


bool Room::hasExit(Room room) {
	for (unsigned int i = 0; i < exits.size(); i++) {
		if (exits[i].equals(room)) {
			return true;
		}
	}
	return false;
}

bool Room::hasExit(std::string exitName) {
	for (unsigned int i = 0; i < exits.size(); i++) {
		if (exits[i].getName() == exitName) {
			return true;
		}
	}
	return false;
}


bool Room::hasMobs() {
	return  !(this->mobs.empty());
}
bool Room::hasMob(std::string name) {
	for (unsigned int i = 0; i < mobs.size(); i++) {
		if (mobs[i].getName() == name) {
			return true;
		}
	}
	return false;
}
bool Room::hasMob(Mob mob) {
	for (unsigned int i = 0; i < mobs.size(); i++) {
		if (mobs[i].equals(mob)) {
			return true;
		}
	}
	return false;
}

bool Room::hasItem(std::string name) {
	for (unsigned int i = 0; i < items.size(); i++) {
		if (items[i].getName() == name) {
			return true;
		}
	}
	return false;
}

bool Room::hasItem(Item item) {
	for (unsigned int i = 0; i < items.size(); i++) {
		if (items[i].equals(item)) {
			return true;
		}
	}
	return false;
}

void Room::attackMob(std::string mobName, int damage, bool weakness) {
	for (unsigned int i = 0; i < mobs.size(); i++) {
		if (mobs[i].getName() == mobName) {
			mobs[i].damageMob(damage, weakness);
			return;
		}
	}
	cout << "Couldn't find the given mob. Trace: @Room::attackMob(std::string mobName, int damage, bool weakness) in @Room.cpp" << endl;
}