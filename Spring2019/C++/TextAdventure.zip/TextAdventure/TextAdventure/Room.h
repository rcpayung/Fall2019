#pragma once
#include "stdafx.h"
#include <iostream>
#include <vector>
#include <string>
#include "Mob.h"
#include "Item.h"


class Room {
private:
	std::vector<Room> exits = {};
	std::vector<Mob> mobs = {};
	std::vector<Item> items = {};
	std::string roomName;
	std::string roomDescription;
	int roomID;
	int numberOfExits = 0;
	int numberOfMobs = 0;
	int numberOfItems = 0;

public:
	Room(int id, std::string roomName, std::string roomDescription, std::vector<Room> exits, std::vector<Mob> mobs, std::vector<Item> items);
	Room(int id, std::string roomName, std::string roomDescription);
	Room();
	~Room();

	// Add data to this Room:
	void addExit(Room room);
	void addMob(Mob mob);
	void addItem(Item item);

	// Remove data from this Room:
	void removeExit(Room room);
	void removeExit(std::string exitName);
	void removeMob(Mob mob);
	void removeMob(std::string mobName);
	void removeItem(Item item);
	void removeItem(std::string itemName);

	int indexOf(Mob mob);
	int indexOf(Item item);
	int indexOf(Room exit);

	// Get data from this Room:
	// Item
	Item getItem(std::string name);
	std::vector<Item> getItems();
	Mob * getMob(std::string name);
	std::vector<Mob> * getMobs();
	Room getExit(std::string name);
	std::vector<Room> getExits();
	//Room data:
	int getId();
	std::string getName();
	std::string getDescription();

	int getNumberOfExits();
	int getNumberOfMobs();
	int getNumberOfItems();

	//Functions: 


	// Print data from this Room:
	std::string toString();

	//Used to check if a room is equal to another one.
	bool equals(Room room);

	bool hasExit(Room room);
	bool hasExit(std::string exitName);
	bool hasMobs();
	bool hasMob(std::string mobName);
	bool hasMob(Mob mob);

	bool hasItem(std::string name);
	bool hasItem(Item item);


	void attackMob(std::string mobName, int damage, bool weakness);

};