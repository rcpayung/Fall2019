#pragma once
#include <string>
#include "Inventory.h"
#include "Mob.h"

using namespace std;

class Player {
public:
	// Constructors:

	Player(string, string);
	Player();
	virtual ~Player();
	
	// Getters:

	string getName();
	string getClassType();
	Inventory * getInventory();
	int getHP();
	int getMP();
	int getMaxHP();
	int getMaxMP();
	bool getDefended();
	
	//Setters:

	void setHP(int);
	void setMP(int);

	//Functions:

	void regenerateHP(int);
	void regenerateMP(int);
	void attackPlayer(Mob &mob, bool isDefended);

	// Parsing:

	string toString();
	string getDeathString();
	void setDeathBy(string str);

private:
	bool isDefended = false;
	string playerName;
	string classType;
	string deathMob;
	int hp;
	int mp;
	int maxHP;
	int maxMP;
	Inventory inventory;
};

