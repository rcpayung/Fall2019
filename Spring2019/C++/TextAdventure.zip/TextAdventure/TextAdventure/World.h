#pragma once
#include "stdafx.h"
#include "Player.h"
#include "Mob.h"
#include "Room.h"

using namespace std;

class World {
public:
	World();
	~World();

	void buildWorld();
	void initialize();

	// Accessors:
	Item findItem(Item item);
	Item findItem(std::string itemName);

	Player * getPlayer();
	Room& getCurrentRoom();
	std::vector<Room> getRoomList();
	std::vector<Item> getItemList();
	std::vector<Mob> getMobList();

	int getScore();

	// sets the current room
	void setCurrentRoom(Room room, std::string commandIfAny);
	void setPlayer(Player &player);
	

	// do Battle
	void attackMob(std::string mobName, int damage, bool weakness);
	void attackPlayer(Mob mob, bool isDefended);

	// Exit the current room of one of its subexits.
	void exitRoom(Room room);
	void exitRoom(std::string roomName);

	// Go back to the previous room.
	void goBack();

	void pickupItem(std::string itemName);
	void pickupItem(Item item);

	std::string toString();
	void printData();
	bool isGameOver();
	void gameOver();

	void printGameOverData();

	Room * findExit(std::string name);

	void checkCommand(std::string command, std::string parameter);

private:
	Room currentRoom;
	Room lastRoom;

	Player player;

	int score = 0;
	bool isGameOverBool = false;

	void addMobs();
	void addRooms();
	void addItems();

	// World data:
	std::vector<Room> roomList = {
		{ 0, "Dungeon Entrance","You have entered the dungeon. Look out for monsters, but be on the look out for treasures, keys, and other goodies." },
	{ 1, "Left Corridor", "You have entered the Left Corridor. Who knows what could be in the Right Corridor. Don't want to head that way. This way only contains a couple of re-animating corpses. Wait wha? SKELETONS!" },
	{ 2, "Right Corridor", "You have entered the Right Corridor. Who knows what could be in the Left Corridor. Don't want to head that way. This way only contains a Dragon. Wait wha? A DRAGON!" },
	{ 3, "Wine Cellar", "You have entered the Wine Cellar. Who knew that Dragons liked the smell of fermenting grapes so much?" },
	{ 4, "Armory", "You have entered the Armory. Look around to try and find something useful, you might need it." },
	{ 5, "Partial Treasure Room", "You have entered the Partial Treasure Room. Corpses are re-animating! Look out!" },
	{ 6, "Throne Room", "You have entered the Throne Room. It seems like whoever ruled in this castle didn't survive for very long. You notice a corpse re-animating in the corner of the room, as well as a Dragon!" },
	{ 7, "Treasure Room", "You have entered the Treasure Room. Looking around, you notice plenty of gold and other goodies! However, theres a boss to guard them! Look out! He's attacking you!" },
	{ 8, "Exit", "You have exited the dungeon. Thanks for playing my Dungeoneering game! It was a bit of a pain in the ass to make, but fun nonetheless. This is only the first of these games, so just wait a while for a better version to be released. Cheers, Riley Payung~" }
	};
	std::vector<Item> itemList = {
		Consumable(1,true,"Health Potion",4), 			//0
		Weapon("Sword Of Flame",10,true,5),				//1
		Weapon("Staff of Magnifying Light",15,true,5),	//2
		Weapon("Bow of the Ancients",20,false,0)		//3
	};
	std::vector<Mob> mobList = {
	{ 0, "Skeleton", 20, 15 },
	{ 1, "Dragon", 30, 20 },
	{ 2, "Dungeon Boss", 70, 20 }
	};
	// End World Data

};