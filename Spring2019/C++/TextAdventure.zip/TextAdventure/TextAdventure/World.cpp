#include "stdafx.h"
#include <iostream>
#include "World.h"

World::World() {

}

World::~World() {

}

void World::addMobs() {
	roomList[1].addMob(mobList[0]); // Skeleton
	roomList[1].addMob(mobList[0]); // Skeleton

	roomList[2].addMob(mobList[1]); // Dragon

	roomList[3].addMob(mobList[1]); // Dragon

	roomList[4].addMob(mobList[0]); // Skeleton

	roomList[5].addMob(mobList[0]); // Skeleton
	roomList[5].addMob(mobList[0]); // Skeleton
	roomList[5].addMob(mobList[0]); // Skeleton

	roomList[6].addMob(mobList[0]); // Skeleton
	roomList[6].addMob(mobList[1]); // Dragon

	roomList[7].addMob(mobList[2]); // Dungeon Boss
}

void World::addRooms() {
	//Room 0 Exits:
	roomList[0].addExit(roomList[1]); // Left Corridor
	roomList[0].addExit(roomList[2]); // Right Corridor
	// Room 1 Exits:
	roomList[1].addExit(roomList[3]); // Wine Cellar
	roomList[1].addExit(roomList[0]); // Dungeon Entrance
	//Room 2 Exits:
	roomList[2].addExit(roomList[3]); // Wine Cellar
	roomList[2].addExit(roomList[0]); // Dungeon Entrance
	// Room 3 Exits:
	roomList[3].addExit(roomList[5]); // Partial Treasure Room
	roomList[3].addExit(roomList[4]); // Armory
	roomList[3].addExit(roomList[2]); // Right Corridor
	roomList[3].addExit(roomList[1]); // Left Corridor
	// Room 4 Exits:
	roomList[4].addExit(roomList[6]); // Throne Room
	roomList[4].addExit(roomList[3]); // Wine Cellar
	// Room 5 Exits:
	roomList[5].addExit(roomList[6]); // Throne Room
	roomList[5].addExit(roomList[3]); // Wine Cellar
	// Room 6 Exits:
	roomList[6].addExit(roomList[7]); // Treasure Room
	roomList[6].addExit(roomList[5]); // Partial Treasure Room
	roomList[6].addExit(roomList[4]); // Armory
	// Room 7 Exits:
	roomList[7].addExit(roomList[8]); // Dungeon Exit
	roomList[7].addExit(roomList[6]); // Throne Room
}

void World::addItems() {
	roomList[0].addItem(itemList[0]); // Health Potion
	roomList[4].addItem(itemList[0]); // Health Potion

	if (this->player.getClassType() == "knight") {
		roomList[4].addItem(itemList[2]);
	}
	else if (this->player.getClassType() == "wizard") {
		roomList[4].addItem(itemList[3]);
	}
	else {
		roomList[4].addItem(itemList[4]);
	}
}

void World::buildWorld() {
	addMobs();
	addRooms();
	addItems();
}

void World::initialize() {
	this->currentRoom = roomList[0];
}


/*
* @param item Asks for an item to search for.
* @return Returns the item found.
* @return Returns an empty item.
*
*/
Item World::findItem(Item item) {
	for (unsigned int i = 0; i < itemList.size(); i++) {
		if (itemList[i].equals(item)) {
			return itemList[i];
		}
	}
	return Item();
}

/*
* @param itemName Asks for the name of the item to search for.
* @return Returns the item found.
* @return Returns an empty item.
*
*/
Item World::findItem(std::string itemName) {
	for (unsigned int i = 0; i < itemList.size(); i++) {
		if (itemList[i].getName() == itemName) {
			return itemList[i];
		}
	}
	return Item();
}

Player * World::getPlayer() {
	return &player;
}

Room& World::getCurrentRoom() {
	return this->currentRoom;
}

std::vector<Room> World::getRoomList() {
	return roomList;
}

std::vector<Item> World::getItemList() {
	return itemList;
}

std::vector<Mob> World::getMobList() {
	return mobList;
}

int World::getScore() {
	return this->score;
}

// sets the current room
void World::setCurrentRoom(Room room, std::string command) {
	if (command == "flee" || command == "Flee" || command == "FLEE") {
		this->lastRoom = currentRoom;
		this->currentRoom = room;
	}
	if (!this->getCurrentRoom().hasMobs()) {
		this->lastRoom = currentRoom;
		this->currentRoom = room;
	}
	else {
		std::cout << "Room currently has Mobs." << endl;
	}
}

void World::setPlayer(Player &player) {
	this->player = player;
}

// do Battle
void World::attackMob(std::string mobName, int damage, bool weakness) {
	if (!getCurrentRoom().hasMobs()) {
		std::cout << "This room doesn't have any mobs to attack. You can now move on to the next room." << std::endl;
	}
	else {
		if (!getCurrentRoom().hasMob(mobName)) {
			std::cout << "This room doesn't have a mob with the name: " << mobName << ". You have wasted a turn." << std::endl;
		}
		else {
			this->getCurrentRoom().getMob(mobName)->damageMob(damage,weakness);
			// Check if mob is dead: (If yes, remove the mob)
			if (getCurrentRoom().getMob(mobName)->getHP() <= 0) {
				currentRoom.removeMob(mobName);
				score += 1250;
				if (!getPlayer()->getInventory()->hasItem("Health Potion")) {
					this->getCurrentRoom().addItem(itemList[0]);
				}
			}
		}
	}
}

void World::attackPlayer(Mob mob, bool isDefended) {
	this->player.attackPlayer(mob, isDefended);
}

// Exit the current room of one of its subexits.
void World::exitRoom(Room room) {
	if (currentRoom.hasMobs()) {
		std::cout << "Cannot exit room when mobs are present. You have wasted a turn." << std::endl;
		return;
	}
	else {
		if (!currentRoom.hasExit(room)) {
			std::cout << "This room does not contain that exit. You have wasted a turn looking for the exit." << std::endl;
		}
		else {
			setCurrentRoom(room, "");
		}
	}
}

void World::exitRoom(std::string roomName) {
	if (this->getCurrentRoom().hasMobs()) {
		std::cout << "Cannot exit room when mobs are present. You have wasted a turn." << std::endl;
		return;
	}
	else {
		if (!this->getCurrentRoom().hasExit(roomName)) {
			std::cout << "This room does not contain that exit. You have wasted a turn looking for the exit." << std::endl;
		}
		else {
			setCurrentRoom(this->getCurrentRoom().getExit(roomName), "");
		}
	}
}

// Go back to the previous room.
void World::goBack() {
	if (this->getCurrentRoom().equals(this->roomList[7])) {
		std::cout << "Cannot return. The boss is guarding the exit" << std::endl;
	}
	else if (this->getCurrentRoom().equals(this->roomList[0]))
		std::cout << "You cannot go back! You are already in the first room!" << std::endl;
	else {
		setCurrentRoom(this->lastRoom, "flee");
	}
}

void World::pickupItem(std::string itemName) {}
void World::pickupItem(Item item) {}


std::string World::toString() {
	return "Not sure what you'd do with this tbh..";
}

void World::printData() {
	if (getCurrentRoom().getName() == "Exit") {
		cout << "DUNGEON CLEARED!" << endl;
		return;
	}
	std::string result = "";
	result.append("===========================================================\n");
	result.append(this->getCurrentRoom().toString() + "\n---------------------\n");
	result.append(this->getPlayer()->toString() + "\n");
	cout << result << endl;
}

bool World::isGameOver() {
	if (this->isGameOverBool) {
		return true;
	}
	return false;
}

void World::gameOver() {
	this->isGameOverBool = true;
}

void World::printGameOverData() {
	score += getPlayer()->getInventory()->numOfItems() * 150;
	score += getPlayer()->getHP() * 100;

	if (getCurrentRoom().getName() == "Exit") {
		cout << "Final Score: " << this->getScore() << endl;
		return;
	}
	cout << "You lost the game. Sorry. Final Score: " << this->getScore() << endl;
}

Room * World::findExit(std::string name) {
	for (unsigned int i = 0; i < roomList.size(); i++) {
		if (roomList[i].getName() == name) {
			return &roomList[i];
		}
	}
	return nullptr;
}

void World::checkCommand(std::string command, std::string parameter) {
	if (command == "enter") {
		if (this->getCurrentRoom().hasExit(parameter)) {
			this->setCurrentRoom(*findExit(parameter), parameter);
		}
		else {
			cout << "Room does not have exit: " << parameter << ". Unforunately, you have wasted a turn." << endl;
		}
	}
	else if (command == "exit" || command == "Exit" || command == "EXIT") {
		isGameOverBool = true;
	}
	else if (command == "pickup" || command == "Pickup" || command == "PICKUP") {
		if (this->getCurrentRoom().hasItem(parameter)) {
			this->getPlayer()->getInventory()->addItem(this->getCurrentRoom().getItem(parameter));
			this->getCurrentRoom().removeItem(parameter);
		}
		else {
			cout << "Room does not have an item called: " << parameter << ". Unfortunately, you have wasted a turn searching for a non-existant item." << endl;
		}
	}
	else if (command == "attack" || command == "Attack" || command == "ATTACK") {
		if (this->getCurrentRoom().hasMob(parameter)) {
			attackMob(parameter, 7, true);
		}
		else {
			cout << "Room does not have mob: " << parameter << ". Unfortunately, you have wasted a turn." << endl;
		}
	}
	else if (command == "use") {
		if (getPlayer()->getInventory()->hasItem(parameter)) {
			this->getPlayer()->getInventory()->useItem(parameter);

			if (parameter == "Health Potion") {
				this->getPlayer()->setHP(this->getPlayer()->getMaxHP());
				cout << "Used Health Potion." << endl;
			}
			if (parameter == "Mana Potion") {
				this->getPlayer()->setMP(this->getPlayer()->getMaxMP());
				cout << "Used Mana Potion." << endl;
			}
		}
	}
	else if (command == "flee" || command == "Flee" || command == "FLEE") {
		this->goBack();
	}
	else if (command == "equip" || command == "EQUIP" || command == "Equip") {
		if (getPlayer()->getInventory()->hasItem(parameter)) {
			this->getPlayer()->getInventory()->useItem(parameter);
		}
		
		// Build Equipment.
	}
	else {
		cout << "Not sure what you meant by " << command << ". Make sure you're using a valid command." << endl;
	}
}