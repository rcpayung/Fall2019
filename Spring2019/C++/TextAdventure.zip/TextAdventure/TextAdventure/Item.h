#pragma once
#include <string>
#include <vector>
#include <iostream>

class Item {
protected:
	static int totalItems;
	int itemID;
	int amount;
	bool stackable;
	std::string itemName;
	int itemType;
public:
	Item(std::string itemName, bool stackable, int amount);
	Item();
	virtual ~Item();

	std::string getName();
	int getType();
	bool getStackable();
	int getID();
	int getAmount();
	bool equals(Item item);
	void increaseAmount();
	void decreaseAmount();
	std::string toString();
};

class Consumable : public Item {
private:
	int buffAmount;
public:
	Consumable(int amount, bool stackable, std::string itemName, int buffAmount);
	Consumable();
	virtual ~Consumable();

	int getBuffAmount();
	std::string toString();
};

class Weapon : public Item {
private:
	int damage;
	int defense;
	bool isDefendable;

public:
	Weapon(std::string itemName, int damage, bool isDefendable, int defense);
	Weapon();
	virtual ~Weapon();

	int getDamage();
	int getDefense();
	bool getDefendable();
	std::string toString();
};