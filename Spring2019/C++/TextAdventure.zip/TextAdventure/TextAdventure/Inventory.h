#pragma once
#include <vector>
#include "Item.h"
#include <iostream>

using namespace std;

class Inventory {
public:
	virtual ~Inventory();

	Inventory();
	bool checkForEmptySlot(Item);
	void addItem(Item);
	void removeItem(Item);
	void removeItem(unsigned int);
	void replace(Item, Item);
	Item getItem(std::string);
	void useItem(Item);
	void useItem(std::string);
	bool hasItem(std::string);
	int numOfItems();

	std::string toString();
	
private:
	vector<Item> items = {};
	unsigned int MAX_ITEMS : 10;
};

