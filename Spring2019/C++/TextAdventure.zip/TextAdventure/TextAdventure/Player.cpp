#include "stdafx.h"
#include "Player.h"

// Constructors:

Player::Player(string name, string type) {
	playerName = name;
	classType = type;

	if (classType == "knight") {
		maxHP = 50;
		maxMP = 25;
		hp = 50;
		mp = 25;
	}
	else if (classType == "wizard") {
		maxHP = 45;
		maxMP = 40;
		hp = maxHP;
		mp = maxMP;
	}
	else if (classType == "archer") {
		maxHP = 40;
		maxMP = 30;
		hp = maxHP;
		mp = maxMP;
	}
}

Player::Player() {
	Player("Player", "knight");
}

Player::~Player() {}

// Getters:

string Player::getName() {
	return this->playerName;
}

string Player::getClassType() {
	return this->classType;
}

Inventory * Player::getInventory() {
	return &inventory;
}

int Player::getHP() {
	return this->hp;
}

int Player::getMP() {
	return this->mp;
}

int Player::getMaxHP() {
	return maxHP;
}

int Player::getMaxMP() {
	return this->maxMP;
}

bool Player::getDefended() {
	//To do.
	return false;
}

// Setters:

void Player::setHP(int hp) {
	cout << "Setting hp" << endl;
	this->hp = hp;
}

void Player::setMP(int mp) {
	this->mp = mp;
}

// Functions:

void Player::regenerateHP(int amount) {
	if ((amount + this->hp) > this->maxHP) {
		this->hp = this->maxHP;
	}
	else {
		this->hp += amount;
	}
}

// Regenerate mana points
void Player::regenerateMP(int amount) {
	if ((amount + this->mp) > this->maxMP) {
		this->mp = this->maxMP;
	}
	else {
		this->mp += amount;
	}
}


void Player::attackPlayer(Mob &mob, bool isDefended) {
	double multiplier = 0.4;
	int totalDamage = 0;

	if (!isDefended) {
		this->setHP((int)(this->hp - (mob.getMaxDamage() * multiplier)));
		totalDamage = (int)(mob.getMaxDamage() * multiplier);
	}
	else {
		this->setHP((int)(this->hp - mob.getMaxDamage()));
		totalDamage = mob.getMaxDamage();
	}
	cout << "Dealt " << totalDamage << " damage to " << this->getName() << endl;
}

// Parsing:

string Player::toString() {
	std::string result = "";

	result.append(this->getName() + ": \n");
	result.append("Info: {Health: " + to_string(getHP()) + "/" + to_string(getMaxHP()) + "}\n");
	result.append("Items: " + getInventory()->toString());

	return result;
}

string Player::getDeathString() {
	return this->getName() + " had his/her legs torn off by " + this->deathMob;
}

void Player::setDeathBy(string str) {
	this->deathMob = str;
}